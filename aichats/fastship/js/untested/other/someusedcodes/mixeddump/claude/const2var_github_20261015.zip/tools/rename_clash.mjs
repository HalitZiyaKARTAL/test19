// rename_clash.mjs <base.html> <variant.html> : per-function binding/reference census of the two pricing functions
import fs from 'fs';
import { createRequire } from 'module';
import { pathToFileURL } from 'url';
import { resolve as __rp } from 'path';
const __NM = process.env.NODE_MODULES || 'node_modules';   // folder that holds acorn and eslint-scope (npm install acorn eslint-scope)
const acorn = await import(pathToFileURL(__rp(__NM, 'acorn/dist/acorn.mjs')).href);
const require = createRequire(import.meta.url);
const eslintScope = require(__rp(__NM, 'eslint-scope'));
const load = f => { const html = fs.readFileSync(f, 'utf8'); const m = html.match(/<script>([\s\S]*?)<\/script>/); return m[1]; };
const analyze = src => {
  const ast = acorn.parse(src, { ecmaVersion: 'latest', sourceType: 'script', ranges: true });
  const sm = eslintScope.analyze(ast, { ecmaVersion: 2022, sourceType: 'script', optimistic: true });
  let kinds = { const: 0, let: 0, var: 0 };
  const walk = n => { if (!n || typeof n.type !== 'string') return; if (n.type === 'VariableDeclaration') kinds[n.kind]++; for (const k in n) { const v = n[k]; if (Array.isArray(v)) v.forEach(walk); else if (v && typeof v.type === 'string') walk(v); } };
  walk(ast);
  const fnScopes = {};
  for (const sc of sm.scopes) if (sc.type === 'function' && sc.block.id && ['normalizeUsage', 'priceUsage'].includes(sc.block.id.name)) fnScopes[sc.block.id.name] = sc;
  const report = {};
  for (const [name, sc] of Object.entries(fnScopes)) {
    // every binding declared anywhere inside this function (its own scope + nested block/arrow scopes)
    const all = {};
    const collect = s => { for (const v of s.variables) { const k = v.name; (all[k] ||= []).push({ scope: s.type, defs: v.defs.map(d => d.type === 'Parameter' ? 'param' : (d.parent && d.parent.kind) || d.type).join('+'), refs: v.references.length }); } s.childScopes.forEach(collect); };
    collect(sc);
    // unresolved references inside the function (names it reads from outside)
    const outer = new Set();
    const thr = s => { for (const r of s.references) if (!r.resolved || !s.variables.includes(r.resolved)) { /* resolved elsewhere */ } s.childScopes.forEach(thr); };
    report[name] = all;
  }
  return { kinds, report };
};
const [base, variant] = process.argv.slice(2);
const B = analyze(load(base)), V = analyze(load(variant));
console.log('declaration kinds  base:', JSON.stringify(B.kinds), ' variant:', JSON.stringify(V.kinds));
for (const fn of ['normalizeUsage', 'priceUsage']) {
  const b = B.report[fn], v = V.report[fn];
  const names = new Set([...Object.keys(b), ...Object.keys(v)]);
  const diff = [];
  for (const n of names) { const sb = JSON.stringify(b[n] || null), sv = JSON.stringify(v[n] || null); if (sb !== sv) diff.push({ name: n, base: b[n] || null, variant: v[n] || null }); }
  console.log('\n== ' + fn + ': ' + Object.keys(v).length + ' distinct names in the variant; bindings that changed vs base:');
  for (const d of diff) console.log('  ' + d.name + '\n     base:    ' + JSON.stringify(d.base) + '\n     variant: ' + JSON.stringify(d.variant));
  // names declared more than once in the variant inside this function (any scope)
  const multi = Object.entries(v).filter(([n, arr]) => arr.length > 1).map(([n, arr]) => n + '×' + arr.length);
  console.log('  names with >1 binding inside the function (variant): ' + (multi.join(', ') || 'none'));
}

// decl_census.mjs <file.html>... : counts of declaration kinds in each file's <script>, and where the remaining let/const sit
import fs from 'fs';
import { pathToFileURL } from 'url';
import { resolve as __rp } from 'path';
const __NM = process.env.NODE_MODULES || 'node_modules';   // folder that holds acorn and eslint-scope (npm install acorn eslint-scope)
const acorn = await import(pathToFileURL(__rp(__NM, 'acorn/dist/acorn.mjs')).href);
function walk(node, fn, fnNode = null) {
  if (!node || typeof node.type !== 'string') return;
  fn(node, fnNode);
  const isFn = /Function/.test(node.type);
  for (const k of Object.keys(node)) {
    if (k === 'type' || k === 'start' || k === 'end' || k === 'loc') continue;
    const v = node[k];
    if (Array.isArray(v)) v.forEach(c => c && typeof c.type === 'string' && walk(c, fn, isFn ? node : fnNode));
    else if (v && typeof v.type === 'string') walk(v, fn, isFn ? node : fnNode);
  }
}
for (const f of process.argv.slice(2)) {
  const html = fs.readFileSync(f, 'utf8'), m = html.match(/<script>([\s\S]*?)<\/script>/);
  const src = m[1], lineOff = html.slice(0, m.index + 8).split('\n').length - 1, lineOf = p => src.slice(0, p).split('\n').length + lineOff;
  const ast = acorn.parse(src, { ecmaVersion: 'latest', sourceType: 'script' });
  const c = { const: 0, let: 0, var: 0, constNames: 0, letNames: 0, varNames: 0, FunctionDeclaration: 0, FunctionExpression: 0, ArrowFunctionExpression: 0, ClassDeclaration: 0, ClassExpression: 0 };
  const lets = [], consts = [];
  walk(ast, (n, fn) => {
    if (n.type === 'VariableDeclaration') { c[n.kind]++; c[n.kind + 'Names'] += n.declarations.length;
      const rec = { line: lineOf(n.start), names: n.declarations.map(d => src.slice(d.id.start, d.id.end)).join(','), fn: fn ? (fn.id ? fn.id.name : 'anon@' + lineOf(fn.start)) : 'top' };
      if (n.kind === 'let') lets.push(rec); if (n.kind === 'const') consts.push(rec); }
    else if (c[n.type] !== undefined) c[n.type]++;
  });
  const byLine = {}; lets.forEach(r => (byLine[r.line] ??= []).push(r.names));
  console.log(f.split('/').pop(), JSON.stringify(c));
  console.log('  let lines: ' + Object.keys(byLine).length + ' -> ' + Object.entries(byLine).map(([l, n]) => 'L' + l + ':' + n.join('|')).join(' '));
  if (consts.length) console.log('  const: ' + consts.map(r => 'L' + r.line + ':' + r.names).join(' '));
}

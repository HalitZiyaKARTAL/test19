// let2var_apply.mjs <in.html> <out.html> <report.txt> [keepLines.json]
// copy opus_12. Rewrites `let` -> `var` (same length, every position stays) in the page's one <script>, then audits:
//  1. parse: all at once and one declaration at a time (acorn and V8 vm.Script)
//  2. binding comparison (eslint-scope, optimistic so the direct evals do not hide IIFE names): every reference whose
//     resolved declaration changes (merges with a parameter / another declaration, capture of an outer or global name)
//  3. loop scan: converted names declared in a loop (head or body, same function) and read by a function created in it
//  4. re-entry scan: declarators without initializer whose block is re-entered by a loop (var keeps the old value)
//  5. early reads: references placed before the declarator ends (same function, or a closure created earlier)
//  6. catch-parameter names, block-level function declarations (Annex B), script-top lets, functions with direct eval
// keepLines.json (optional): array of declaration start positions to leave as `let`.
import fs from 'fs';
import vm from 'vm';
import { loadPage, parse, walk, isFn, isLoop, patIds, analyzeScopes } from './lib.mjs';

const [inPath, outPath, repPath, keepPath] = process.argv.slice(2);
const P = loadPage(inPath), { src, lc, lineOf } = P;
const keep = new Set(keepPath ? JSON.parse(fs.readFileSync(keepPath, 'utf8')) : []);
const out = []; const say = s => out.push(s);
const ast = parse(src);

// ---------- collect the lets ----------
const lets = [];
const fnNodes = [];
const catchClauses = [], blockFns = [], evalSites = [];
walk(ast, (n, anc) => {
  const parent = anc[anc.length - 1];
  if (isFn(n)) fnNodes.push(n);
  if (n.type === 'CatchClause') catchClauses.push({ n, anc });
  if (n.type === 'FunctionDeclaration' && parent && !(parent.type === 'Program' || (parent.type === 'BlockStatement' && isFn(anc[anc.length - 2]))))
    blockFns.push(n);
  if (n.type === 'CallExpression' && n.callee.type === 'Identifier' && n.callee.name === 'eval') evalSites.push({ n, anc });
  if (n.type !== 'VariableDeclaration' || n.kind !== 'let') return;
  if (src.slice(n.start, n.start + 3) !== 'let') throw new Error('keyword not at start: ' + lc(n.start));
  let fi = anc.length - 1; while (fi >= 0 && !isFn(anc[fi]) && anc[fi].type !== 'Program') fi--;
  const fnNode = anc[fi];
  const inner = anc.slice(fi + 1);                       // nodes between the function and the declaration
  const head = parent && /^For(In|Of)?Statement$/.test(parent.type) && (parent.init === n || parent.left === n) ? parent : null;
  // loops that re-run the declaration's scope: every loop strictly enclosing the container in this function;
  // for a for-head the for statement itself creates per-iteration copies (closure semantics) but runs init once
  const enclosingLoops = inner.filter(x => isLoop(x) && x !== head);
  const atFnTop = parent === fnNode || (fnNode.type !== 'Program' && parent === fnNode.body);
  lets.push({ n, start: n.start, end: n.end, line: lineOf(n.start), fnNode, parent, head, enclosingLoops, atFnTop, anc,
    decls: n.declarations.map(d => ({ d, ids: patIds(d.id), init: !!d.init })) });
});
lets.sort((a, b) => a.start - b.start);
const fnName = f => f.type === 'Program' ? 'script-top' : (f.id ? f.id.name : (() => {
  // name of an arrow/function expression: the variable or property it is assigned to
  return 'anon@' + lc(f.start); })());
say('lets: ' + lets.length + ' declarations, ' + lets.reduce((k, l) => k + l.decls.reduce((j, d) => j + d.ids.length, 0), 0) + ' names');

// ---------- build ----------
const build = pred => { let s = '', last = 0; for (const l of lets) { s += src.slice(last, l.start) + (pred(l) ? 'var' : 'let'); last = l.start + 3; } return s + src.slice(last); };
const conv = l => !keep.has(l.start);
const cand = build(conv);
const v8 = s => { try { new vm.Script(s, { filename: 'x.js' }); return 'ok'; } catch (e) { return String(e.message); } };
const ac = s => { try { parse(s); return 'ok'; } catch (e) { return e.message; } };
say('\n== 1. parse');
say('all converted' + (keep.size ? ' (kept ' + keep.size + ')' : '') + ': acorn ' + ac(cand) + ' | V8 ' + v8(cand));
let oneBad = 0;
for (const l of lets) {
  const s = build(x => x === l);
  const a = ac(s), b = v8(s);
  if (a !== 'ok' || b !== 'ok') { oneBad++; say('  alone as var FAILS: ' + lc(l.start) + ' `' + src.slice(l.start, Math.min(l.end, l.start + 50)).replace(/\s+/g, ' ') + '` acorn: ' + a + ' | V8: ' + b); }
}
say('one at a time: ' + (lets.length - oneBad) + ' parse, ' + oneBad + ' fail');
// all but one (each declaration alone left as let)
let allButBad = 0;
for (const l of lets) { const s = build(x => x !== l && conv(x)); if (ac(s) !== 'ok' || v8(s) !== 'ok') { allButBad++; say('  all but ' + lc(l.start) + ' FAILS'); } }
say('all but one (each left as let in turn): ' + (lets.length - allButBad) + ' parse, ' + allButBad + ' fail');
fs.writeFileSync(outPath, P.withScript(cand));

// ---------- 2. bindings ----------
say('\n== 2. binding comparison (eslint-scope, optimistic)');
const A = analyzeScopes(ast), B = analyzeScopes(parse(cand));
const declStarts = new Set(lets.filter(conv).flatMap(l => l.decls.flatMap(d => d.ids.map(i => i.start))));
const groups = new Map();
let nChanged = 0;
for (const [pos, a] of A.refs) {
  const b = B.refs.get(pos);
  if (!b) { say('  reference missing after: ' + a.name + ' ' + lc(pos)); continue; }
  if (a.key === b.key) continue;
  nChanged++;
  const k = a.name + '|' + a.key + '|' + b.key;
  const g = groups.get(k) || { name: a.name, before: a.key, after: b.key, refs: [] };
  g.refs.push({ pos, w: a.write, r: a.read, init: a.init }); groups.set(k, g);
}
for (const pos of B.refs.keys()) if (!A.refs.has(pos)) say('  new reference after: ' + lc(pos));
const keyLc = k => k.startsWith('global:') ? k : k.split(',').map(p => lc(+p)).join('+');
say('references whose binding changed: ' + nChanged + ' in ' + groups.size + ' groups');
for (const g of groups.values()) say('  ' + g.name + ': ' + keyLc(g.before) + ' -> ' + keyLc(g.after) + ' ; ' + g.refs.length + ' refs: ' +
  g.refs.map(r => lc(r.pos) + (r.init ? '(init)' : r.w && r.r ? '(rw)' : r.w ? '(w)' : '')).join(' '));
// merged variables after conversion: every variable with >1 def where one def is a converted let
say('\nvariables with more than one declaration after conversion that involve a converted let:');
const seenV = new Set();
for (const sc of B.sm.scopes) for (const v of sc.variables) {
  if (seenV.has(v) || v.defs.length < 2) continue;
  if (!v.defs.some(d => declStarts.has(d.name.start))) continue;
  seenV.add(v);
  say('  ' + v.name + ' in ' + sc.type + '@' + lc(sc.block.start) + ': defs ' + v.defs.map(d => d.type + (d.parent && d.parent.kind ? '/' + (declStarts.has(d.name.start) ? 'let>var' : d.parent.kind) : '') + '@' + lc(d.name.start)).join(', ') +
    ' ; refs ' + v.references.map(r => lc(r.identifier.start) + (r.init ? '(init)' : r.isWrite() && r.isRead() ? '(rw)' : r.isWrite() ? '(w)' : '')).join(' '));
}

// ---------- helpers on the original scopes ----------
const varOfDecl = new Map();        // id start -> eslint Variable (original)
for (const sc of A.sm.scopes) for (const v of sc.variables) for (const d of v.defs) varOfDecl.set(d.name.start, v);
const fnOfPos = pos => { let best = null; for (const f of fnNodes) if (f.start <= pos && pos < f.end && (!best || f.start >= best.start)) best = f; return best || ast; };
const closureChain = (pos, fnNode) => { // functions between fnNode and the reference (outermost first)
  const chain = []; for (const f of fnNodes) if (f.start <= pos && pos < f.end && f.start > fnNode.start && f.end <= fnNode.end && f !== fnNode) chain.push(f);
  return chain.sort((a, b) => a.start - b.start); };
const snip = (s, e, n = 90) => src.slice(s, Math.min(e, s + n)).replace(/\s+/g, ' ');

// ---------- 3. loops ----------
say('\n== 3. converted names declared in a loop (head or body, same function) and read/written by a function created in that loop');
let loopHits = 0;
for (const l of lets.filter(conv)) {
  const inLoop = l.head || l.enclosingLoops.length;
  if (!inLoop) continue;
  for (const d of l.decls) for (const id of d.ids) {
    const v = varOfDecl.get(id.start); if (!v) { say('  ?? no variable for ' + id.name + ' ' + lc(id.start)); continue; }
    for (const r of v.references) {
      const chain = closureChain(r.identifier.start, l.fnNode);
      if (!chain.length) continue;
      loopHits++;
      const c = chain[0];
      say('  ' + id.name + ' (decl ' + lc(id.start) + (l.head ? ', loop head ' + l.head.type : ', in ' + l.enclosingLoops.map(x => x.type + '@' + lc(x.start)).join('>')) + ') used at ' + lc(r.identifier.start) +
        (r.isWrite() ? ' (write)' : '') + ' inside function ' + lc(c.start) + ' `' + snip(Math.max(0, c.start - 40), c.start + 50) + '`');
    }
  }
}
say('loop/closure uses: ' + loopHits);

// ---------- 4. re-entry ----------
say('\n== 4. declarators without initializer whose block a loop re-enters (var keeps the previous value)');
let reHits = 0;
for (const l of lets.filter(conv)) for (const d of l.decls) {
  if (d.init) continue;
  const forInOf = l.head && l.head.type !== 'ForStatement';
  if (forInOf) continue;                                  // assigned on every iteration
  if (!l.enclosingLoops.length) continue;
  reHits++;
  say('  ' + d.ids.map(i => i.name).join(',') + ' ' + lc(d.d.start) + ' in ' + l.enclosingLoops.map(x => x.type + '@' + lc(x.start)).join('>') + ' : `' + snip(l.start, l.end, 80) + '`');
}
say('re-entered declarators without initializer: ' + reHits);
say('declarators without initializer anywhere (for reference): ' + lets.filter(conv).flatMap(l => l.decls.filter(d => !d.init && !(l.head && l.head.type !== 'ForStatement')).map(d => d.ids.map(i => i.name).join(',') + '@' + lc(d.d.start))).join(' '));

// ---------- 5. early reads ----------
say('\n== 5. references placed before their declarator ends');
let early = 0;
for (const l of lets.filter(conv)) for (const d of l.decls) for (const id of d.ids) {
  const v = varOfDecl.get(id.start); if (!v) continue;
  for (const r of v.references) {
    const p = r.identifier.start;
    if (p >= d.d.end) continue;
    if (r.init && p === id.start) continue;
    const chain = closureChain(p, l.fnNode);
    early++;
    say('  ' + id.name + ' declared ' + lc(id.start) + (l.fnNode.type === 'Program' ? ' (script top)' : ' in ' + fnName(l.fnNode)) + ' referenced at ' + lc(p) + (r.isWrite() ? ' (write)' : '') +
      (chain.length ? ' inside function ' + (chain[0].id ? chain[0].id.name : 'anon') + '@' + lc(chain[0].start) : ' SAME FUNCTION'));
  }
}
say('early references: ' + early);

// ---------- 6. other rules ----------
say('\n== 6. other rules');
const catchHits = [];
for (const { n } of catchClauses) {
  const names = n.param ? patIds(n.param).map(i => i.name) : [];
  for (const l of lets.filter(conv)) if (l.start > n.body.start && l.end <= n.body.end) for (const d of l.decls) for (const id of d.ids) if (names.includes(id.name)) catchHits.push(id.name + ' ' + lc(id.start) + ' inside catch(' + names.join(',') + ') ' + lc(n.start));
}
say('converted names equal to an enclosing catch parameter: ' + (catchHits.length ? catchHits.join('; ') : 'none'));
say('block-level function declarations: ' + (blockFns.length ? blockFns.map(f => f.id.name + '@' + lc(f.start)).join(' ') : 'none'));
say('lets at script top: ' + (lets.filter(l => l.fnNode.type === 'Program').map(l => lc(l.start)).join(' ') || 'none'));
say('direct eval calls: ' + evalSites.length);
for (const e of evalSites) {
  const f = fnOfPos(e.n.start);
  const inF = lets.filter(l => conv(l) && l.fnNode === f);
  say('  eval at ' + lc(e.n.start) + ' in function ' + lc(f.start) + ' `' + snip(f.start, f.end, 60) + '`; converted lets of that function: ' + (inF.map(l => l.decls.flatMap(d => d.ids.map(i => i.name)).join(',') + '@' + lc(l.start)).join(' ') || 'none'));
}
const argUsers = fnNodes.filter(f => { let u = false; walk(f.body, (n) => { if (n.type === 'Identifier' && n.name === 'arguments') u = true; }); return u; });
say('functions reading `arguments`: ' + (argUsers.map(f => lc(f.start)).join(' ') || 'none'));

// ---------- list ----------
say('\n== list of let declarations');
for (const l of lets) say((conv(l) ? 'var ' : 'LET ') + lc(l.start) + ' fn=' + fnName(l.fnNode) + (l.atFnTop ? ' top' : ' block:' + l.parent.type) + (l.head ? ' head:' + l.head.type : '') +
  (l.enclosingLoops.length ? ' loops:' + l.enclosingLoops.length : '') + ' `' + snip(l.start, l.end, 70) + '`');
fs.writeFileSync(repPath, out.join('\n') + '\n');
console.log(out.slice(0, 12).join('\n'));

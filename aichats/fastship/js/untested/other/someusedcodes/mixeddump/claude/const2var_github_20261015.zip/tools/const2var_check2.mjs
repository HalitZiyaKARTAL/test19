// const2var_check2.mjs <in.html> <out_let.html>
// 1. For each of the consts my apply script kept, test it ALONE as var (others var too, the rest of the kept set const).
// 2. Build the variant "every const -> var, the parse-breakers -> let", parse it, write it.
// 3. Hoisting check: list every reference to a converted const that sits BEFORE the declaration (same function or a
//    nested function): with var such a read would give undefined instead of a ReferenceError.
import fs from 'fs';
import { createRequire } from 'module';
import { pathToFileURL } from 'url';
import { resolve as __rp } from 'path';
const __NM = process.env.NODE_MODULES || 'node_modules';   // folder that holds acorn and eslint-scope (npm install acorn eslint-scope)
const acorn = await import(pathToFileURL(__rp(__NM, 'acorn/dist/acorn.mjs')).href);
const require = createRequire(import.meta.url);
const eslintScope = require(__rp(__NM, 'eslint-scope'));
const [inPath, outPath] = process.argv.slice(2);
const html = fs.readFileSync(inPath, 'utf8');
const m = html.match(/<script>([\s\S]*?)<\/script>/);
const src = m[1], scriptStart = m.index + '<script>'.length;
const lineOff = html.slice(0, scriptStart).split('\n').length - 1;
const lineOf = pos => src.slice(0, pos).split('\n').length + lineOff;
const parse = s => acorn.parse(s, { ecmaVersion: 'latest', sourceType: 'script', locations: true, ranges: true });
function walkAll(node, fn, fnNode = null) {
  if (!node || typeof node.type !== 'string') return;
  fn(node, fnNode);
  const isFn = /Function/.test(node.type);
  for (const k of Object.keys(node)) {
    if (k === 'type' || k === 'start' || k === 'end' || k === 'loc' || k === 'range') continue;
    const v = node[k];
    if (Array.isArray(v)) v.forEach(c => c && typeof c.type === 'string' && walkAll(c, fn, isFn ? node : fnNode));
    else if (v && typeof v.type === 'string') walkAll(v, fn, isFn ? node : fnNode);
  }
}
const patNames = (p, out = []) => { if (!p) return out;
  if (p.type === 'Identifier') out.push(p.name);
  else if (p.type === 'ObjectPattern') p.properties.forEach(q => patNames(q.type === 'RestElement' ? q.argument : q.value, out));
  else if (p.type === 'ArrayPattern') p.elements.forEach(q => patNames(q, out));
  else if (p.type === 'AssignmentPattern') patNames(p.left, out);
  else if (p.type === 'RestElement') patNames(p.argument, out);
  return out; };
const ast = parse(src);
const consts = [];
walkAll(ast, (n, fnNode) => { if (n.type === 'VariableDeclaration' && n.kind === 'const') consts.push({ start: n.start, end: n.end, line: lineOf(n.start), names: n.declarations.flatMap(d => patNames(d.id)), fn: fnNode ? fnNode.start : -1, text: src.slice(n.start, Math.min(n.end, n.start + 40)).replace(/\s+/g, ' ') }); });
consts.sort((a, b) => a.start - b.start);
const build = kw => { let s = '', last = 0; for (const c of consts) { s += src.slice(last, c.start) + (kw(c) || 'var  '); last = c.start + 5; } return s + src.slice(last); };
const tryParse = s => { try { parse(s); return 'ok'; } catch (e) { return e.message.replace(/ \(\d+:\d+\)$/, ''); } };
// the three my apply script kept
const kept = consts.filter(c => (c.line === 675 && c.names.includes('l')) || (c.line === 676 && c.names.includes('e')));
console.log('kept consts: ' + kept.map(c => 'L' + c.line + ' `' + c.text + '`').join(' | '));
for (const k of kept) {
  const r = tryParse(build(c => c === k ? 'var  ' : (kept.includes(c) ? 'const' : 'var  ')));
  console.log('  only `' + k.text + '` as var (the other kept stay const): ' + r);
}
console.log('all three as let: ' + tryParse(build(c => kept.includes(c) ? 'let  ' : 'var  ')));
const letSrc = build(c => kept.includes(c) ? 'let  ' : 'var  ').replace(/\b(var|let)   /g, '$1 ').replace(/\b(var|let)  ([^ ])/g, '$1 $2');
console.log('clean let-variant parses: ' + tryParse(letSrc));
fs.writeFileSync(outPath, html.slice(0, scriptStart) + letSrc + html.slice(scriptStart + src.length));
// hoisting check on the original: a direct read of a converted const before its own declarator ends (not inside a
// function created later, which runs after the initialization); plus any write to a converted const (impossible under
// const, silently allowed under var)
const sm = eslintScope.analyze(ast, { ecmaVersion: 2022, sourceType: 'script' });
const convertedStarts = new Set(consts.filter(c => !kept.includes(c)).map(c => c.start));
const fnOf = pos => { let f = -1; walkAll(ast, n => { if (/Function/.test(n.type) && n.start <= pos && pos <= n.end && n.start >= f) f = n.start; }); return f; };
const hits = [], writes = [];
for (const scope of sm.scopes) for (const v of scope.variables) {
  if (!v.defs.length || v.defs[0].type !== 'Variable' || v.defs[0].parent.kind !== 'const') continue;
  const decl = v.defs[0].parent; if (!convertedStarts.has(decl.start)) continue;
  const dnode = v.defs[0].node, declFn = fnOf(decl.start);
  for (const r of v.references) {
    const p = r.identifier.start;
    if (r.isWrite() && !r.init) writes.push('L' + lineOf(p) + ' ' + v.name);
    if (p >= dnode.start && p < dnode.end && r.init) continue;
    if (p < dnode.end && fnOf(p) === declFn) hits.push('L' + lineOf(p) + ' ' + v.name + ' (declared L' + lineOf(decl.start) + ')');
  }
}
console.log('direct reads before the declarator ends (same function): ' + hits.length + (hits.length ? '\n  ' + hits.join('\n  ') : ''));
console.log('writes to a converted const: ' + writes.length + (writes.length ? '\n  ' + writes.join('\n  ') : ''));

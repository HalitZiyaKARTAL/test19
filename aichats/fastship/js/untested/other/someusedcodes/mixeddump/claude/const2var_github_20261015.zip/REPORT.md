# const → var in ai_chat.html: what a blanket edit does

The user's question (2026-10-14 20:26Z): «i am fine with everything using var actually, as long as doesnt cause a side effect that can annoy me, i dont see a point in using const when its written by ai  then reviewed later too». This folder holds the check of a blanket `const` → `var` edit of the repo's `ai_chat.html` (sha 1ef7ec2f, 405 `const` declarations in its script), done on a copy; the repo is untouched.

## Result

- **401 of the 405 `const` declarations can become `var` with no change in behaviour** (402 was the first-pass count; the third pass below found one more that must not be `var`). Three must stay `const` (or be renamed), because `var` makes the page fail to parse at load — nothing would run:
  - L675 `normalizeUsage`: the block `const l = cacheSum(n)` clashes with the function's `let l` (a `var` hoists to the function and collides with the `let`).
  - L676 `priceUsage`: the block `const e = [[...]].filter(...)` and the loop `for (const e in l)` clash with the block-level `let e` that encloses the loop.
- `const CHAT_ID = 'default'` (L385) becomes `var CHAT_ID = 'default'`, which is the one line the user wanted reassignable.
- `const todo = JSON.parse(...)` (L1375, outside the app's IIFE) becomes a true global `window.todo`; harmless.

## What changes under the hood, and why it does not matter today

A `var` is function-scoped and hoisted, a `const` is block-scoped. The scope comparison (eslint-scope, every identifier reference of the original resolved against the converted script) found 127 references in 29 groups whose declaration changed. All are of three harmless kinds:

1. **Block constants that reuse a parameter's name** in the four minified usage/pricing functions `usageValue`, `mergeUsage`, `normalizeUsage`, `priceUsage` (L671–L676): after the edit the block assigns the parameter itself instead of shadowing it. In every case the parameter is not read again after that block (or the block returns), so the computed values are the same.
2. **Sibling blocks that each declared the same name** (`source` twice in `checkGen` L475, `path` in `updateNodeDOM` try/catch L932–933, `n`/`incomingId`/`targetChatId` in the two loops of `saveHistory` L1107–L1136): they now share one variable, but each block assigns it before reading it, and the only closures made inside those loops run synchronously (`forEach`), so no closure sees a later value.
3. **Two block constants at the top level of the app's IIFE** (`uuid` L388, `k` L505) now live in the IIFE's function scope; nothing else uses those names there.

Reading a name before its declaration line would now give `undefined` instead of a ReferenceError; the app has no such read (it would already throw today).

## How it was checked

- `tools/const2var_apply.mjs`: parses the script with acorn, rewrites every `const` keyword in place (same length, so every position stays), re-parses, reverts only the declarations that break the parse (the three above), then compares the binding of every identifier reference between the original and the converted script with eslint-scope.
- `tools/const2var_boot.mjs`: boots the original and the converted page in headless Chromium (new storage each), records console and page errors, walks the five settings tabs, flips a setting and saves it, imports `sample_export.json` (a two-message chat, branch mode), types into the input, reloads, and snapshots the page state at each step. Both pages produced the same snapshots and no errors (boot3.jsonl).
- The converted file equals the original except for the keyword (279 lines touched), parses, and holds no key or token.

## Second pass (21:13Z): `let` for the three, and two more checks

- **Correction.** Only two of the three really break the parse as `var`: `const l = cacheSum(n)` (L675) and the loop `for (const e in l)` (L676). The block `const e = [[...]]` (L676) parses as `var`; the first script reverted it only because it reverts every same-named `const` of the function in one go. Tested one at a time with `tools/const2var_check2.mjs`.
- **`let` works for all three.** `let` is block-scoped like `const`, so none of the collisions exists; the behaviour is identical (they are temporaries that nothing reassigns). `ai_chatvar_candidate2.html` = candidate 1 with `var` → `let` at those three spots: no `const` left, 402 `var`, and the same headless run as the original (boot4.jsonl: identical snapshots, no errors). Renaming them would also allow `var`, but that edits the minified function text for no gain.
- **Hoisting check.** A `var` is readable before its declaration (value `undefined`) where a `const` throws. Of the 402 converted declarations, no reference reads the name before its own declarator ends inside the same function; the only earlier references sit inside functions created later (closures), which run after the initialization. So no read changes from a thrown error to `undefined`.
- **Write check.** No code assigns to any converted name after its initialization (under `const` that would throw; under `var` it would silently succeed). So no assignment changes behaviour.

## Third pass (21:33Z): what the Opus checker found that this report had missed

- **A real miss in candidates 1 and 2.** In `priceUsage` (L676) the branch `else{const t=p-r; …}` sits inside the block `if(null!=p){…}`, and that block ends with `return{usage:t, …}`. As `var`, `t=p-r` overwrites the function's first parameter `t` (the usage object), so that `return` hands back a number instead of the usage. It only happens when a provider reports its own cost (`cost_usd`, `total_cost_usd`, `billing.cost_usd`, or xAI's `cost_in_usd_ticks`) and that cost is not below the app's own estimate: then the message loses its token counts and the stats and header counter fall back to characters, and the broken usage is saved with the message. The built-in DeepSeek, OpenAI, Gemini and Z.ai providers send no cost, so they are not affected. The sentence above, "the parameter is not read again after that block", was wrong for this one function.
- **Fix: `let t=p-r`.** `ai_chatvar_candidate3.html` = candidate 2 with that one change: 401 `var`, 4 `let`, no `const` (sha256 0e69c9d4…). It is byte-identical to the checker's own test file `opus_e/candidate2_fix_test.html`. The checker compared the pricing code of the original and of the fixed file on 200,000 random usage/pricing cases (no difference; candidate 2 differed in 104,833) and drove both pages in headless Chromium through send, regenerate, version switch, inline branch, a second tab, reload and the clash dialog, with and without a provider cost field (no difference with the fix, no page errors).
- **A gap in this report's method.** The hoisting and write scans above used eslint-scope in its default mode, which leaves references unresolved in any function that contains a direct `eval`; the app's whole outer function does, so those two scans silently covered only names declared outside it. The checker re-ran them with that limit turned off and reached the same conclusions, so they stand, but on the checker's evidence rather than this report's. The binding comparison in the first pass had the same blind spot for the outer function; the runtime A/B never sent a message, so the pricing code did not run there.

## Verdict after the three Opus checks (21:45Z)

All three checkers (opus_c, opus_d, opus_e; independent, same brief) found the same single miss, the `t` of `priceUsage`, and nothing else; each confirmed everything else in this report with its own tools (random-input comparisons of the pricing code: 200,000 / 120,000 / 200,000 cases; scope audits run without the eval blind spot; headless Chromium runs through send, regenerate, versions, branches, import, reload, recovery, two tabs, and a provider that reports its own cost).

- **`ai_chatvar_candidate3.html`** (401 `var`, 4 `let`, no `const`): the fix all three built and tested; byte-identical to opus_c's `cand2_fixed.html`, opus_d's `cand2_fixtest.html` and opus_e's `candidate2_fix_test.html`.
- **`ai_chatvar_candidate4.html`** (402 `var`, 3 `let`: `l`, the `for … e in l`, and `t`; sha256 689307a0…): as many `var` as possible, since the block `e=[[…]]` needs no `let`; byte-identical to opus_c's `cand3.html`, which opus_c tested the same way. The only difference from candidate 3 is that one keyword.

Either is fine; candidate 4 matches the user's wish for `var` everywhere most closely, candidate 3 carries the checks of all three agents. Candidates 1 and 2 should not be used.

## Files

- `ai_chatvar_candidate1.html`: the converted page (402 `var`, 3 `const` kept, 150,078 characters = 150,335 bytes, sha256 3dab682a…). Not uploaded anywhere; the user decides whether to use it.
- `ai_chatvar_candidate2.html`: the same with `let` at the three spots (402 `var`, 3 `let`, no `const`, sha256 7942c4ca…). Superseded by candidate 3.
- `ai_chatvar_candidate3.html`: candidate 2 plus `let t=p-r` in priceUsage (401 `var`, 4 `let`, no `const`, sha256 0e69c9d4…). The one to use.
- `../tools/const2var_check2.mjs`: the second-pass checks (one-at-a-time parse test, the `let` build, the hoisting and write scans).
- `var.html`: the length-preserving intermediate (`var  ` with two spaces); `orig.html`: the repo copy it was made from.
- `sample_export.json`, `boot.jsonl` / `boot2.jsonl` / `boot3.jsonl`: the headless runs.

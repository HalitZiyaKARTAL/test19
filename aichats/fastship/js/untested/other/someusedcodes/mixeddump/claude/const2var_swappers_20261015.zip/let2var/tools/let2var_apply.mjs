// let2var_apply.mjs <in.html> <out.html> [keep=L<line>:<name>,...]
// 1. every `let` declaration of the page's <script> -> `var` (same length: every position stays the same);
// 2. one-at-a-time parse test (each let alone as var, all others unchanged) and the full build; declarations listed
//    in keep= stay `let`; if the full build does not parse, it stops and says where;
// 3. binding comparison: every identifier reference resolved with eslint-scope (optimistic: the app's IIFE holds a
//    direct eval, the default mode would leave its references unresolved) in the input and the output; each reference
//    whose set of declarations changed is listed, grouped by name and function.
import fs from 'fs';
import { createRequire } from 'module';
import * as acorn from '/opt/node22/lib/node_modules/eslint/node_modules/acorn/dist/acorn.mjs';
const require = createRequire(import.meta.url);
const eslintScope = require('/opt/node22/lib/node_modules/eslint/node_modules/eslint-scope');
const [inPath, outPath, keepArg] = process.argv.slice(2);
const keepSpec = new Set((keepArg || '').replace(/^keep=/, '').split(',').filter(Boolean));
const html = fs.readFileSync(inPath, 'utf8'), m = html.match(/<script>([\s\S]*?)<\/script>/);
const src = m[1], scriptStart = m.index + 8, lineOff = html.slice(0, scriptStart).split('\n').length - 1;
const line = p => src.slice(0, p).split('\n').length + lineOff;
const col = p => p - src.lastIndexOf('\n', p - 1);
const parse = s => acorn.parse(s, { ecmaVersion: 'latest', sourceType: 'script', ranges: true });
const tryParse = s => { try { parse(s); return null; } catch (e) { return e; } };
const patNames = (p, out = []) => { if (!p) return out;
  if (p.type === 'Identifier') out.push(p.name);
  else if (p.type === 'ObjectPattern') p.properties.forEach(q => patNames(q.type === 'RestElement' ? q.argument : q.value, out));
  else if (p.type === 'ArrayPattern') p.elements.forEach(q => patNames(q, out));
  else if (p.type === 'AssignmentPattern') patNames(p.left, out);
  else if (p.type === 'RestElement') patNames(p.argument, out);
  return out; };
const ast = parse(src), lets = [];
(function walk(n) { if (!n || typeof n.type !== 'string') return;
  if (n.type === 'VariableDeclaration' && n.kind === 'let') {
    if (src.slice(n.start, n.start + 3) !== 'let') throw Error('keyword not at start, L' + line(n.start));
    lets.push({ start: n.start, end: n.end, line: line(n.start), names: n.declarations.flatMap(d => patNames(d.id)) }); }
  for (const k of Object.keys(n)) { if (k === 'type' || k === 'start' || k === 'end' || k === 'range') continue; const v = n[k];
    if (Array.isArray(v)) v.forEach(c => c && typeof c.type === 'string' && walk(c)); else if (v && typeof v.type === 'string') walk(v); } })(ast);
lets.sort((a, b) => a.start - b.start);
lets.forEach(l => { l.key = 'L' + l.line + ':' + l.names.join(','); l.keep = [...keepSpec].some(s => s === l.key || s === 'L' + l.line + ':' + l.names[0] || s === '@' + l.start); });
const build = conv => { let s = '', last = 0; for (const l of lets) { s += src.slice(last, l.start) + (conv(l) ? 'var' : 'let'); last = l.start + 3; } return s + src.slice(last); };
console.log('let declarations: ' + lets.length + ' (names ' + lets.reduce((n, l) => n + l.names.length, 0) + '); kept by request: ' + lets.filter(l => l.keep).length);
// one at a time
const alone = [];
for (const l of lets) { const e = tryParse(build(x => x === l)); if (e) alone.push(l.key + ' @' + l.start + ' -> ' + e.message); }
console.log('each let alone as var, parse failures: ' + alone.length); alone.forEach(x => console.log('  ' + x));
const out = build(l => !l.keep), err = tryParse(out);
if (err) { console.log('FULL BUILD DOES NOT PARSE: ' + err.message + ' at L' + line(err.pos)); process.exit(2); }
fs.writeFileSync(outPath, html.slice(0, scriptStart) + out + html.slice(scriptStart + src.length));
console.log('full build parses; converted ' + lets.filter(l => !l.keep).length + ', kept as let ' + lets.filter(l => l.keep).length + ' -> ' + outPath);
// binding comparison
const refsOf = s => { const a = parse(s), sm = eslintScope.analyze(a, { ecmaVersion: 2022, sourceType: 'script', optimistic: true }), r = new Map();
  for (const sc of sm.scopes) for (const ref of sc.references) r.set(ref.identifier.start, { name: ref.identifier.name, write: ref.isWrite(), init: !!ref.init,
    defs: ref.resolved ? ref.resolved.defs.map(d => d.name.start).sort((x, y) => x - y).join(',') : 'global', from: ref.from.variableScope.block.start });
  return r; };
const A = refsOf(src), B = refsOf(out), groups = new Map();
let n = 0;
for (const [p, a] of A) { const b = B.get(p); if (!b) { console.log('missing ref at L' + line(p)); continue; } if (a.defs === b.defs) continue; n++;
  const k = a.name + ' | ' + a.defs + ' -> ' + b.defs, g = groups.get(k) || { name: a.name, before: a.defs, after: b.defs, refs: [] }; g.refs.push(p); groups.set(k, g); }
const L = d => d === 'global' ? 'global' : d.split(',').map(x => 'L' + line(+x) + ':' + col(+x)).join('+');
console.log('references whose declaration set changed: ' + n + ' in ' + groups.size + ' groups');
for (const g of groups.values()) console.log('  ' + g.name + ': [' + L(g.before) + '] -> [' + L(g.after) + '] refs ' + g.refs.map(p => 'L' + line(p) + ':' + col(p) + (A.get(p).write ? (A.get(p).init ? 'i' : 'w') : '')).join(' '));

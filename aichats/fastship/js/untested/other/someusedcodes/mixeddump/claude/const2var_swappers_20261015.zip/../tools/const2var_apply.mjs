// const2var_apply.mjs <in.html> <out.html>
// Rewrites every `const` declaration of the page's <script> to `var  ` (same length, so every position stays),
// re-parses, reverts only the declarations that make the parse fail (reports them), writes the converted page,
// then compares identifier binding (eslint-scope) between the original and the converted script and lists
// every reference that now resolves to a different / merged declaration.
import fs from 'fs';
import { createRequire } from 'module';
import * as acorn from '/opt/node22/lib/node_modules/eslint/node_modules/acorn/dist/acorn.mjs';
const require = createRequire(import.meta.url);
const eslintScope = require('/opt/node22/lib/node_modules/eslint/node_modules/eslint-scope');

const [inPath, outPath] = process.argv.slice(2);
const html = fs.readFileSync(inPath, 'utf8');
const m = html.match(/<script>([\s\S]*?)<\/script>/);
const src = m[1], scriptStart = m.index + '<script>'.length;
const lineOff = html.slice(0, scriptStart).split('\n').length - 1;
const lineOf = pos => src.slice(0, pos).split('\n').length + lineOff;
const parse = s => acorn.parse(s, { ecmaVersion: 'latest', sourceType: 'script', locations: true, ranges: true });

function walkAll(node, fn, parent = null, fnNode = null) {
  if (!node || typeof node.type !== 'string') return;
  fn(node, parent, fnNode);
  const isFn = /Function/.test(node.type);
  for (const k of Object.keys(node)) {
    if (k === 'type' || k === 'start' || k === 'end' || k === 'loc' || k === 'range') continue;
    const v = node[k];
    if (Array.isArray(v)) v.forEach(c => c && typeof c.type === 'string' && walkAll(c, fn, node, isFn ? node : fnNode));
    else if (v && typeof v.type === 'string') walkAll(v, fn, node, isFn ? node : fnNode);
  }
}
const patNames = (p, out = []) => {
  if (!p) return out;
  if (p.type === 'Identifier') out.push(p.name);
  else if (p.type === 'ObjectPattern') p.properties.forEach(q => patNames(q.type === 'RestElement' ? q.argument : q.value, out));
  else if (p.type === 'ArrayPattern') p.elements.forEach(q => patNames(q, out));
  else if (p.type === 'AssignmentPattern') patNames(p.left, out);
  else if (p.type === 'RestElement') patNames(p.argument, out);
  return out;
};

const ast = parse(src);
const consts = [];
walkAll(ast, (n, parent, fnNode) => {
  if (n.type === 'VariableDeclaration' && n.kind === 'const') {
    if (src.slice(n.start, n.start + 5) !== 'const') throw new Error('unexpected keyword at ' + n.start);
    consts.push({ start: n.start, line: lineOf(n.start), names: n.declarations.flatMap(d => patNames(d.id)), fn: fnNode ? fnNode.start : -1 });
  }
});
consts.sort((a, b) => a.start - b.start);
const keep = new Set();
const build = () => { let s = '', last = 0; for (const c of consts) { s += src.slice(last, c.start) + (keep.has(c.start) ? 'const' : 'var  '); last = c.start + 5; } return s + src.slice(last); };
let converted, reverted = [];
for (let iter = 0; iter < 60; iter++) {
  converted = build();
  try { parse(converted); break; }
  catch (e) {
    const pos = e.pos, name = (e.message.match(/Identifier '([^']+)'/) || [])[1];
    let fn = -1; walkAll(ast, n => { if (/Function/.test(n.type) && n.start <= pos && pos <= n.end && n.start >= fn) fn = n.start; });
    const cands = consts.filter(c => !keep.has(c.start) && c.fn === fn && name && c.names.includes(name));
    if (!cands.length) { console.log('PARSE ERROR not fixable by reverting a const: ' + e.message + ' at L' + lineOf(pos)); process.exit(2); }
    cands.forEach(c => { keep.add(c.start); reverted.push('L' + c.line + ' ' + name + ' (error at L' + lineOf(pos) + ': ' + e.message.replace(/ \(\d+:\d+\)$/, '') + ')'); });
  }
}
const outHtml = html.slice(0, scriptStart) + converted + html.slice(scriptStart + src.length);
fs.writeFileSync(outPath, outHtml);
console.log('consts total: ' + consts.length + '; converted to var: ' + (consts.length - keep.size) + '; kept as const (parse would fail): ' + keep.size);
reverted.forEach(r => console.log('  KEEP ' + r));

// binding comparison
const analyze = s => {
  const a = parse(s), sm = eslintScope.analyze(a, { ecmaVersion: 2022, sourceType: 'script' }), refs = new Map();
  for (const scope of sm.scopes) for (const r of scope.references) {
    const v = r.resolved;
    refs.set(r.identifier.start, { name: r.identifier.name, defs: v ? v.defs.map(d => d.name.start).sort((x, y) => x - y) : null });
  }
  return refs;
};
const before = analyze(src), after = analyze(converted);
const changes = new Map();
for (const [pos, b] of before) {
  const a = after.get(pos);
  const bk = b.defs ? b.defs.join(',') : 'global', ak = a && a.defs ? a.defs.join(',') : 'global';
  if (bk === ak) continue;
  const key = b.name + '|' + bk + '|' + ak;
  const e = changes.get(key) || { name: b.name, before: b.defs, after: a && a.defs, refs: [] };
  e.refs.push(lineOf(pos)); changes.set(key, e);
}
console.log('references whose binding changed: ' + [...changes.values()].reduce((n, e) => n + e.refs.length, 0) + ' (' + changes.size + ' groups)');
for (const e of changes.values()) {
  const L = d => d ? '[' + [...new Set(d.map(lineOf))].join(',') + ']' : 'global';
  console.log('  ' + e.name + ': decl ' + L(e.before) + ' -> ' + L(e.after) + ' ; refs at L' + [...new Set(e.refs)].join(',L'));
}

// lib.mjs: shared helpers for the let -> var analysis (copy opus_12)
import fs from 'fs';
import { createRequire } from 'module';
import { pathToFileURL } from 'url';
import { resolve as __rp } from 'path';
const __NM = process.env.NODE_MODULES || 'node_modules';   // folder that holds acorn and eslint-scope (npm install acorn eslint-scope)
const acorn = await import(pathToFileURL(__rp(__NM, 'acorn/dist/acorn.mjs')).href);
const require = createRequire(import.meta.url);
export const eslintScope = require(__rp(__NM, 'eslint-scope'));

export function loadPage(path) {
  const html = fs.readFileSync(path, 'utf8');
  const all = [...html.matchAll(/<script\b[^>]*>/g)];
  if (all.length !== 1) throw new Error('expected exactly one <script>, found ' + all.length);
  const m = html.match(/<script>([\s\S]*?)<\/script>/);
  const src = m[1], scriptStart = m.index + '<script>'.length;
  const lineOff = html.slice(0, scriptStart).split('\n').length - 1;
  const lineStarts = [0]; for (let i = 0; i < src.length; i++) if (src[i] === '\n') lineStarts.push(i + 1);
  const lineOf = pos => { let lo = 0, hi = lineStarts.length - 1; while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (lineStarts[mid] <= pos) lo = mid; else hi = mid - 1; } return lo + 1 + lineOff; };
  const colOf = pos => { const l = lineOf(pos) - 1 - lineOff; return pos - lineStarts[l] + 1; };
  const lc = pos => 'L' + lineOf(pos) + ':' + colOf(pos);
  const withScript = s => html.slice(0, scriptStart) + s + html.slice(scriptStart + src.length);
  return { html, src, scriptStart, lineOff, lineOf, colOf, lc, withScript };
}

export const parse = s => acorn.parse(s, { ecmaVersion: 'latest', sourceType: 'script', locations: true, ranges: true });

export const isFn = n => n && (n.type === 'FunctionDeclaration' || n.type === 'FunctionExpression' || n.type === 'ArrowFunctionExpression');
export const isLoop = n => n && /^(ForStatement|ForInStatement|ForOfStatement|WhileStatement|DoWhileStatement)$/.test(n.type);

// walk with the full ancestor chain (ancestors[0] = Program ... ancestors[last] = parent)
export function walk(node, fn, ancestors = []) {
  if (!node || typeof node.type !== 'string') return;
  fn(node, ancestors);
  const next = ancestors.concat(node);
  for (const k of Object.keys(node)) {
    if (k === 'type' || k === 'start' || k === 'end' || k === 'loc' || k === 'range') continue;
    const v = node[k];
    if (Array.isArray(v)) { for (const c of v) if (c && typeof c.type === 'string') walk(c, fn, next); }
    else if (v && typeof v.type === 'string') walk(v, fn, next);
  }
}

export const patIds = (p, out = []) => {
  if (!p) return out;
  if (p.type === 'Identifier') out.push(p);
  else if (p.type === 'ObjectPattern') p.properties.forEach(q => patIds(q.type === 'RestElement' ? q.argument : q.value, out));
  else if (p.type === 'ArrayPattern') p.elements.forEach(q => patIds(q, out));
  else if (p.type === 'AssignmentPattern') patIds(p.left, out);
  else if (p.type === 'RestElement') patIds(p.argument, out);
  return out;
};

// every identifier reference -> resolution key (sorted def positions of the resolved variable, or global:name)
export function analyzeScopes(ast) {
  const sm = eslintScope.analyze(ast, { ecmaVersion: 2022, sourceType: 'script', optimistic: true });
  const refs = new Map();
  for (const scope of sm.scopes) for (const r of scope.references) {
    const v = r.resolved;
    const defs = v ? v.defs.map(d => d.name.start).sort((a, b) => a - b) : null;
    refs.set(r.identifier.start, { name: r.identifier.name, key: defs ? defs.join(',') : 'global:' + r.identifier.name, defs, v, r,
      write: r.isWrite(), read: r.isRead(), init: !!r.init });
  }
  return { sm, refs };
}

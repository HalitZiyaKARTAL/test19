<!-- report written by core Opus copy 10 (its final reply, saved verbatim by the helper because the harness blocks report files from subagents) -->

I converted 156 of the app's 160 `let`s to `var` with no change in behaviour; 4 must stay `let`. The result is `ai_chatvar_candidate5_10.html`. I could not write `REPORT.md`: this environment blocks report files from sub-agents. The report is below, ready to save. The repo was not touched, and I did not open the other copies' folders.

My folder is `const2var/let2var/opus_10/`.

## Result

- **Base:** candidate 4 (sha256 689307a0…) has 0 `const`, 160 `let` declarations (264 names) and 402 `var`.
- **Converted (156):** this includes all 49 names at the top of the app's main function (`settings`, `chatTree`, `activeViewList`, `providers`, `activeProviderId`, `agents`, `TAB_PID`, the save flags, the counters, …).
- **Kept (4):** all four are block temporaries in the two minified pricing functions, `normalizeUsage` (L675) and `priceUsage` (L676). Three are the ones the const pass already left as `let`. The fourth, `let n=nn(e.inputUnknown)`, is one of the app's own `let`s.
- **`ai_chatvar_candidate5_10.html`** (sha256 ac6c141a…, 150,329 bytes): 0 `const`, 4 `let`, 558 `var`. It differs from candidate 4 only in those 156 keywords, on 116 lines. `let` and `var` are the same length, so nothing else moves.
- **Optional `ai_chatvar_candidate5_10_nolet.html`** (sha256 53a4c899…): no `let` at all.
  - The four are renamed to unused one-letter names, then made `var`: `l`→`g` in normalizeUsage; `n`→`g`, `t`→`d`, `e`→`k` in priceUsage. That is 15 identifiers on 2 lines.
  - It passed the pricing fuzz (20,000 rounds, 0 differences) and the headless run (identical).
  - It is only worth taking if a remaining `let` bothers you: those four are temporaries that no hook can reach.

For your hooks: code added later inside the main function can now declare any of those names again with `var`, which `let` refused at load time. Assigning to them from the console or an add-on already worked.

## The four that stay `let`

I converted each one on its own and compared it with candidate 4, both by fuzz and by driving the real page headless (`e2e_ablation_summary.txt`).

| Where | As `var` it would | What you'd see |
|---|---|---|
| L675:1054, `let l=cacheSum(n)` | overwrite the "unpriced" flag with the cache-token sum | Every DeepSeek reply (any usage with cache counts) is stored as unpriced, and its cost shows a `+` (`0.0019¢+`, header `1.28¢+`). 5,114 of 20,000 cases differ. |
| L676:630, `let n=nn(e.inputUnknown)` | overwrite the provider-reported cost before it is read | Happens when some input tokens aren't covered by cache counts (e.g. a custom provider without a usage profile) and the price list has `inputUnknown`, equal cache prices, or a reported cost. The stored cost becomes a one-token price (0.038¢ → 0.0001¢) and the header total drops (1.28¢ → 1.24¢). 3,199 cases differ. |
| L676:1126, `let t=p-r` | overwrite the usage that is returned | The known const-pass bug: usage stored as a number and tokens lost (footer `117c` instead of `36t`). 11,848 cases differ. |
| L676:1170, `for(let e in l)` | leave a key name in the `split` flag | When a reported cost is a hair below the computed one, the stored `split` becomes true. Nothing reads it today. 156 cases differ. |

## What `var` changes underneath, without changing behaviour

These come from my scope audit (eslint-scope in optimistic mode, so the app's two `eval`s don't hide main-function names).

- **Shared names:** 13 groups (109 references) now share one variable inside a function: `regChange`, `usageValue`, `priceUsage`'s parameters `e`/`n`, `renderPathTopoAware`, `saveHistory`, `healTree`, and the click handler's loops.
  - In each, the name is set before it is read in its own block.
  - No function created in one block runs while another block's value is live.
- **Loops:** 5 functions created inside a loop read a loop variable. All run immediately (a `bootRead` promise executor and `saveHistory` `forEach` callbacks).
- **None present:** a `let` without initial value inside a loop, a read before the declaration, a `let` used across `switch` cases, or a `let` at program level.
- **Early reads:** `resetStopBtn` reads two names declared one line later, but it only runs after start-up. Candidate 4 under "pause on all exceptions" never hit an initialization error, except ones I provoked on purpose.

## Two deliberate behaviour changes

**Agent expressions in swarm mode.** `AA()` evaluates each agent's priority and frequency text with `eval`, so that code sees AA's locals `h`, `p`, `d`, `i`, `a`, `P`, which are now `var`. Normal expressions behave the same. Only expressions that declare one of those six names, or read `P` in their own priority, differ:

| Agent expression | Candidate 4 | Candidate 5 |
|---|---|---|
| priority reads `P` | error toast, agent skipped (A answers) | no error, B answers |
| priority `var i="A";9` | error toast ("already declared"), B answers | A answers |
| frequency `var p=100;true` | error toast, B answers | no agent answers at all |

If you'd rather keep the old errors for those cases, leave AA's four `let`s as they are.

**The agents loop's `i`.** `for(let i in agents)` at start-up leaves `i` (value `'_'`) visible to the eval console, pasted add-ons and `worker:false` tool code. Before, reading `i` there was an error. Nothing reads it after start-up, and none of the four add-ons uses an undeclared `i`.

## Add-ons

99.js, B1, B2 and B3 read 7 of the app's `let`s, assign none and `swap()` none. Pasted into candidates 4 and 5 in headless Chromium, they behaved identically, apart from the deliberate `i` probe and the timing-only `ms` field:
- 12/13 swapped functions, all restored by `disable()`;
- tool turns with and without the worker, a plain turn, regenerate, export, re-paste;
- the same request bodies and the same saved chat tree.

No edits needed.

## How it was checked

- **Text:** only the 156 keywords differ from candidate 4.
- **Pricing fuzz** (L510, L651–652, L670–684), including reported costs placed around the computed one:
  - candidate 4 vs 5 (two seeds) and the original vs 5: 1,804,000 comparisons each, 0 differences;
  - block coverage of L671–676: everything ran except two blocks that cannot run.
- **Headless page comparison:** 9 scenarios × 2 rounds on candidates 4 and 5, against a local mock provider. They covered:
  - **core:** sends, regenerate, versions, branches, xAI and reported costs, a provider without cache counts, a non-streamed reply, and a reload mid-stream;
  - **versions:** unread dots on both sides, browser back/forward, and Stop;
  - **two tabs:** the merge path, including the clash dialog;
  - **recovery:** stream-buffer recovery after reload;
  - **settings:** the agent registry rows, the provider JSON editor, Reset, and the eval console;
  - **swarm:** batch candidates plus synthesis;
  - **import/export:** every import mode, a corrupted file through the repair dialog, and restore from backup;
  - **legacy migration** of old keys, and **fresh boot**.

  Everything was identical except the deliberate `i` probe, and both rounds matched. No request left the machine.

## Notes

- **Earlier pricing fuzzes:** opus_d's and opus_e's random generators repeat after 16,403 draws. Their "120,000/200,000 cases" were therefore at most about 10,500 distinct inputs. My run of the original against candidate 5 (better generator, measured coverage) re-confirms the const pass's pricing result.
- **Two-tab display glitch, already in the original:** when two tabs each start a first message, switching branches leaves message #1 showing the other branch's text until a full re-render. It is identical on the original, candidate 4 and candidate 5; I left it alone.

Files are in `opus_10/`:
- ai_chatvar_candidate5_10.html
- ai_chatvar_candidate5_10_nolet.html
- tools/ (scan, fuzz, headless and add-on harnesses)
- scan_keep4.txt
- let_table.txt (all 160 declarations)

<!-- report written by core Opus copy 12 (its final reply, saved verbatim by the helper because the harness blocks report files from subagents) -->

I'm copy 12. Of the 160 `let`s in candidate 4, **156 can become `var` with no change in behaviour; 4 cannot**, so they stay `let` in the new file. I couldn't save `REPORT.md` because the environment blocks report files from subagents, so the full report is this reply.

The new file is `SP/const2var/let2var/opus_12/ai_chatvar_candidate5_12.html`:
- **Counts:** 0 `const`, 4 `let`, 558 `var`.
- **Size and hash:** 150,329 bytes, the same as candidate 4; sha256 `ac6c141a…`.
- **What changed:** only the 156 keywords, on 116 lines.

## The four that stay `let`

All four are in the two minified pricing functions on lines 675 and 676. As `var` the page still loads; it just saves different numbers. Two of them only fail to parse while their partner is still `let`, so "change everything and check it loads" would have accepted the broken version.

| # | Declaration | Collides with | What changes as `var` | When |
|---|---|---|---|---|
| 1 | `normalizeUsage`: `let l=cacheSum(n)` (L675) | the function's "unpriced" flag `l` | The flag gets overwritten, so costs gain or lose the "+" (unknown part) marker. | Any reply with cache counts. A DeepSeek reply with cache hits shows `0.01818¢+` instead of `0.01818¢`. |
| 2 | `priceUsage`: `let n=nn(e.inputUnknown)` (L676) | the parameter `n`, the cost the provider reported | The reported cost is dropped. The total falls back to the price-list estimate (`0.044¢+` instead of `0.104¢`). | The provider reports its own cost and its cache counts don't cover the whole input. |
| 3 | `priceUsage`: `let t=p-r` (L676) | the parameter `t`, the usage | The usage is saved as a number and the token counts are lost. This is the const pass's known case. | The reported cost is not below the price-list estimate. |
| 4 | `priceUsage`: `for(let e in l)` (L676) | the `split` flag `e` | The saved `split` flag becomes true. No screen reads it. | The reported cost is a rounding hair below the estimate. |

Each one alone, measured against candidate 4 on 50,000 random rounds (750,000 comparisons): 27,515 / 8,387 / 102,540 / 4 differences.

If you want zero `let`, there is an optional file: `ai_chatvar_candidate5_12_zero_let.html` (0 `let`, 562 `var`, sha256 `d08fa683…`).
- **How:** the four get fresh local names (`l2`, `n2`, `t2`, `e2`), which appear nowhere else in the file.
- **What changed:** only lines 675–676, plus 15 bytes.
- **Tests:** it passed every test the main file did.
- **The trade-off:** it edits the minified text beyond keywords. For hooks it gains nothing, because these are locals inside two pricing helpers that no hook can reach.

## What this means for hooks

For anything run through the eval console, like the 99 add-ons, `let` and `var` behave the same:
- `activeProviderId = "gw"` changes the app's value with either.
- `var activeProviderId = "zzz"` never does: it creates a new variable that exists only for that console run, with either.

What `var` does give you is in the app's own source: a second `var x` written into the app's main function is allowed, where a second `let x` stops the page from loading.

## Why the other 156 are safe

- **Shared names:** after the change, 30 groups of references (109 in total) share a variable with another declaration of the same name. In every case the name is set before it is read, and nothing created inside reads it later. The places:
  - `regChange` (each block returns)
  - `usageValue`
  - `priceUsage`'s `e` flag and `n=0` (the parameters aren't read after that point)
  - `renderPathTopoAware`'s four loops
  - `saveHistory`'s two loops
  - `healTree`'s `arr`
  - the two unread-dot loops in the click handler
- **No other binding moves:** no reference starts pointing at an outer name, a global or a `catch` parameter.
- **Loops:** the functions created inside loops are synchronous `forEach` callbacks and one Promise executor that runs immediately. No `let x;` without a value sits in a loop.
- **Reads before a declaration:** the only one is `resetStopBtn` reading two names declared on the next line, and it only runs after start-up. Nothing that runs during start-up reads a `let` before its line.
- **Other rules:** no function declared inside a block, no `let` at the script's top level, no `arguments`, no reads across `switch` cases.
- **Two small, by-design changes:**
  - `for (let i in agents)` now leaves an app-wide `i` equal to `"_"`. Only code run through eval (the console, add-on tool code, agent expressions) can see it.
  - Agent priority/frequency expressions run through `eval`. An expression that declares a variable with the same name as one of AA's own variables would now change it instead of failing.

## How I checked it

| Check | Result |
|---|---|
| Parse (acorn and V8) | All at once: passes. One at a time: 158 of 160 (the two failures are #1 and #4). All but one: 160 of 160. |
| Binding comparison (eslint-scope, optimistic so the app's `eval`s don't hide names) | 109 references changed, all of them the merges listed above |
| Pricing differential test (lines 510 and 649–700, 15 kinds of comparison per round) | Candidate 4 vs 5: 0 of 3,000,000 differ. Zero-let: 0 of 3,000,000. Repo original vs 5: 0 of 1,500,000. All 160 as `var` (the deliberately broken control): 120,896 of 750,000 differ. |
| Browser A/B in headless Chromium against a local streaming mock | Candidate 4, 5 and zero-let identical in two runs, with every thrown exception recorded and none of them "Cannot access … before initialization" |
| 99.js, B1, B2, B3 pasted on candidate 4, 5 and zero-let (12 runs) | Identical once the tool's run time is masked; no errors; every swapped function restored by `disable()` |

The browser runs covered:
- **Single tab:**
  - send, regenerate, version and branch switching, back/forward, both unread dots, Stop
  - the agent list controls; swarm with agent expressions and a batch agent
  - settings with Reset
  - provider and model switching, and reported costs equal to, a hair below, half of and above the price list
  - every import mode, including a broken legacy tree through the repair dialog
  - restore from backup, export, reload
- **Two tabs:** both edit the same message and the clash dialog opens.
- **Recovery:** a reply cut by a reload is restored from the stream buffer.

## Existing bug I found (not changed)

The agents list's "＋" (new agent) button throws `r.active is not a function`, so new agents can't be added from the UI. It's the same in the repo original. A one-line fix would be `id=m[1]||r.active?.()`.

## Files

Everything is in `SP/const2var/let2var/opus_12/`:
- the two HTML files above
- `keep4.json`: the positions of the four kept `let`s
- `tools/`, with all my scripts; the add-on runner is copied unchanged from the const pass's opus_d check
- outputs: `analysis_keep4.txt`, `extra_scans.txt`, `price_fuzz.txt`, `price_fuzz_single.txt`, `demo_cases.txt`, `e2e_run1.jsonl`, `e2e_run2.jsonl`, `e2e_cmp1.txt`, `e2e_cmp2.txt`, `addon_run1.jsonl`, `addon_cmp.txt`, `console_decl.txt`

The other files there are test copies, not for use: `draft_allvar.html` (the broken all-`var` control), `single/` and `addon_pages/`. The repo is untouched, and the test runs used dummy keys only.
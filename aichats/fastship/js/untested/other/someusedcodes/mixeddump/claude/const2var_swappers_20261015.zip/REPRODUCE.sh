#!/usr/bin/env bash
# Rebuilds every candidate from the original app with the swapper scripts and checks each sha256.
# Run from SP/const2var (SP = the scratchpad): bash REPRODUCE.sh
# Needs Node 22 with acorn + eslint-scope at /opt/node22/lib/node_modules/eslint/node_modules/ (the paths inside the scripts).
set -e
mkdir -p repro
want() { local got; got=$(sha256sum "$1" | cut -c1-8); if [ "$got" = "$2" ]; then echo "OK   $1 $got"; else echo "DIFF $1 got $got want $2"; fi; }
# const pass
node ../tools/const2var_apply.mjs orig.html repro/c1_raw.html > repro/log_apply.txt            # every const -> "var  " (same length), parse-breakers reverted
python3 - <<'PY'                                                                                   # the spacing clean-up that made candidate 1
import re; s=open('repro/c1_raw.html').read(); s=re.sub(r'\bvar   ','var ',s); s=re.sub(r'\bvar  \[','var [',s); open('repro/c1.html','w').write(s)
PY
node ../tools/const2var_check2.mjs orig.html repro/c2.html > repro/log_check2.txt                # candidate 2: the three parse-breakers as `let`, clean spacing
python3 - <<'PY'                                                                                   # candidates 3 and 4: one keyword each
s=open('repro/c2.html').read(); assert s.count('var t=p-r')==1; s=s.replace('var t=p-r','let t=p-r'); open('repro/c3.html','w').write(s)
assert s.count('let e=[["cacheHit"')==1; s=s.replace('let e=[["cacheHit"','var e=[["cacheHit"'); open('repro/c4.html','w').write(s)
PY
want repro/c1.html 3dab682a; want repro/c2.html 7942c4ca; want repro/c3.html 0e69c9d4; want repro/c4.html 689307a0
# let pass (copy opus_12's script; copies 10 and 11 produce the same bytes with theirs)
node let2var/opus_12/tools/let2var_apply.mjs repro/c4.html repro/c5_12.html repro/rep12.txt let2var/opus_12/keep4.json > repro/log_12.txt
want repro/c5_12.html ac6c141a
# the two zero-let renames
node let2var/opus_12/tools/zero_let.mjs repro/c5_12.html repro/zero12.html > repro/log_zero12.txt
node let2var/opus_10/tools/nolet_variant.mjs repro/c5_12.html repro/nolet10.html > repro/log_nolet10.txt
want repro/zero12.html d08fa683; want repro/nolet10.html 53a4c899
# census of the results
node ../tools/decl_census.mjs repro/c4.html repro/c5_12.html repro/zero12.html repro/nolet10.html | grep -v '^  let lines' | cut -c1-120

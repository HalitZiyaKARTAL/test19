// l2v_scan.mjs <base.html> [--keep L:C,L:C,...] [--out variant.html] [--list]
// let -> var audit of the app page (copy opus_10).
// For every `let` declaration in the page's <script> (positions are html line:column of the `let` keyword):
//  1. builds the variant: every `let` keyword -> `var` (same length, so every position stays), except the kept ones;
//     checks that the variant parses;
//  2. resolves every identifier reference of both scripts with eslint-scope in optimistic mode (the app's direct
//     `eval` calls would otherwise leave every IIFE-level reference unresolved) and lists each reference whose set of
//     declarations changed, grouped by name and hoisting function;
//  3. per converted let: closures created inside the loop that holds it (per-iteration binding lost), declarators
//     without initialiser inside a loop (a `var` keeps the previous pass's value), reads placed before the
//     declarator in the same function (TDZ error -> undefined), closures created before the declarator (deferred
//     reads, check call time), reads from another `case` of the same switch, lets visible to a direct `eval` inside
//     their own function (eval'd `var X` / TDZ reads differ), block lets whose name becomes function-wide, and
//     program-level lets (would become window properties).
import fs from 'node:fs';
import { createRequire } from 'node:module';
import * as acorn from '/opt/node22/lib/node_modules/eslint/node_modules/acorn/dist/acorn.mjs';
const require = createRequire(import.meta.url);
const eslintScope = require('/opt/node22/lib/node_modules/eslint/node_modules/eslint-scope');

const args = process.argv.slice(2);
const inPath = args[0];
const opt = k => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : null; };
const keep = new Set((opt('--keep') || '').split(',').map(s => s.trim()).filter(Boolean));
const outPath = opt('--out');
const listAll = args.includes('--list');

const html = fs.readFileSync(inPath, 'utf8');
const m = html.match(/<script>([\s\S]*?)<\/script>/);
const src = m[1], scriptStart = m.index + '<script>'.length;
const htmlLineStarts = [0]; for (let i = 0; i < html.length; i++) if (html[i] === '\n') htmlLineStarts.push(i + 1);
const LC = pos => { const h = scriptStart + pos; let lo = 0, hi = htmlLineStarts.length - 1; while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (htmlLineStarts[mid] <= h) lo = mid; else hi = mid - 1; } return 'L' + (lo + 1) + ':' + (h - htmlLineStarts[lo] + 1); };
const ctx = (s, e, w = 60) => src.slice(Math.max(0, s - w), Math.min(src.length, e + w)).replace(/\s+/g, ' ');
const opts = { ecmaVersion: 'latest', sourceType: 'script', locations: true, ranges: true };
const parse = s => acorn.parse(s, opts);

const isFn = n => /^(FunctionDeclaration|FunctionExpression|ArrowFunctionExpression)$/.test(n.type);
const isLoop = n => /^(For|ForIn|ForOf|While|DoWhile)Statement$/.test(n.type);
const patNames = (p, out = []) => { if (!p) return out;
  if (p.type === 'Identifier') out.push(p);
  else if (p.type === 'ObjectPattern') p.properties.forEach(q => patNames(q.type === 'RestElement' ? q.argument : q.value, out));
  else if (p.type === 'ArrayPattern') p.elements.forEach(q => patNames(q, out));
  else if (p.type === 'AssignmentPattern') patNames(p.left, out);
  else if (p.type === 'RestElement') patNames(p.argument, out);
  return out; };

const ast = parse(src);
// the IIFE = the async arrow called at the top
const iife = ast.body.find(s => s.type === 'ExpressionStatement' && s.expression.type === 'CallExpression')?.expression.callee;
const parent = new Map();
(function walk(n, p) {
  if (!n || typeof n.type !== 'string') return;
  parent.set(n, p);
  for (const k of Object.keys(n)) { if (['type', 'start', 'end', 'loc', 'range'].includes(k)) continue; const v = n[k];
    if (Array.isArray(v)) v.forEach(c => c && typeof c.type === 'string' && walk(c, n)); else if (v && typeof v.type === 'string') walk(v, n); }
})(ast, null);
const fnLabel = f => {
  if (f.type === 'Program') return 'program';
  if (f === iife) return 'IIFE';
  if (f.id) return f.id.name;
  const p = parent.get(f);
  if (p && p.type === 'VariableDeclarator' && p.id.type === 'Identifier') return p.id.name;
  if (p && p.type === 'Property') return (p.key.name || p.key.value) + ':';
  if (p && p.type === 'AssignmentExpression') return src.slice(p.left.start, p.left.end) + '=';
  if (p && (p.type === 'CallExpression' || p.type === 'NewExpression')) return src.slice(p.callee.start, Math.min(p.callee.end, p.callee.start + 40)) + '(cb)';
  if (p && p.type === 'AssignmentPattern') return 'default-param';
  return 'anon';
};
const fnOf = n => { let p = parent.get(n); while (p && !isFn(p) && p.type !== 'Program') p = parent.get(p); return p; };
const label = f => fnLabel(f) + '@' + LC(f.start);
// ---- 1. the let declarations
const lets = [];
(function walk(n) {
  if (!n || typeof n.type !== 'string') return;
  if (n.type === 'VariableDeclaration' && n.kind === 'let') {
    if (src.slice(n.start, n.start + 3) !== 'let') throw new Error('keyword? ' + LC(n.start));
    const f = fnOf(n), chain = []; let p = parent.get(n);
    while (p && p !== f) { chain.push(p); p = parent.get(p); }
    const par = parent.get(n), body = f.type === 'Program' ? f : f.body;
    const isHead = par && isLoop(par) && (par.init === n || par.left === n);
    lets.push({ node: n, key: LC(n.start), fn: f, chain, direct: par === body, isHead, headOf: isHead ? par : null,
      loops: chain.filter(isLoop), inCase: par && par.type === 'SwitchCase' ? par : null,
      decls: n.declarations.map(d => ({ d, ids: patNames(d.id), init: !!d.init })) });
  }
  for (const k of Object.keys(n)) { if (['type', 'start', 'end', 'loc', 'range'].includes(k)) continue; const v = n[k];
    if (Array.isArray(v)) v.forEach(c => c && typeof c.type === 'string' && walk(c)); else if (v && typeof v.type === 'string') walk(v); }
})(ast);
lets.sort((a, b) => a.node.start - b.node.start);
const unknownKeep = [...keep].filter(k => !lets.some(l => l.key === k));
if (unknownKeep.length) { console.log('UNKNOWN --keep entries: ' + unknownKeep.join(' ')); process.exit(2); }
const conv = lets.filter(l => !keep.has(l.key));
console.log('let declarations: ' + lets.length + ' (' + lets.reduce((n, l) => n + l.decls.reduce((k, d) => k + d.ids.length, 0), 0) + ' names); converted: ' + conv.length + '; kept: ' + (lets.length - conv.length) + (keep.size ? ' [' + [...keep].join(' ') + ']' : ''));

// ---- 2. the variant
let variant = '', last = 0;
for (const l of conv) { variant += src.slice(last, l.node.start) + 'var'; last = l.node.start + 3; }
variant += src.slice(last);
let parseErr = null; try { parse(variant); } catch (e) { parseErr = e.message + ' at ' + LC(e.pos); }
console.log('variant parses: ' + (parseErr ? 'NO: ' + parseErr : 'yes'));
if (outPath && !parseErr) { fs.writeFileSync(outPath, html.slice(0, scriptStart) + variant + html.slice(scriptStart + src.length)); console.log('written: ' + outPath); }
if (parseErr) process.exit(1);

// ---- 3. binding comparison
const smA = eslintScope.analyze(ast, { ecmaVersion: 2022, sourceType: 'script', optimistic: true });
const astB = parse(variant), smB = eslintScope.analyze(astB, { ecmaVersion: 2022, sourceType: 'script', optimistic: true });
const refMap = sm => { const r = new Map(); for (const s of sm.scopes) for (const x of s.references) r.set(x.identifier.start, { ref: x, defs: x.resolved ? x.resolved.defs.map(d => d.name.start).sort((a, b) => a - b) : null }); return r; };
const rA = refMap(smA), rB = refMap(smB);
// declaration kind of a def position, from the base script
const defKind = new Map();
for (const s of smA.scopes) for (const v of s.variables) for (const d of v.defs) {
  let k = d.type;
  if (d.type === 'Variable') k = d.parent.kind + (d.parent.kind === 'let' ? (keep.has(LC(d.parent.start)) ? '(kept)' : '') : '') + (s.type === 'function' || s.type === 'global' ? '' : '@' + s.type);
  defKind.set(d.name.start, k);
}
const D = list => list ? list.map(p => LC(p) + ' ' + (defKind.get(p) || '?')).join(' + ') : 'global/unresolved';
const groups = new Map(); let changed = 0;
for (const [pos, a] of rA) {
  const b = rB.get(pos), ka = a.defs ? a.defs.join(',') : 'G', kb = b && b.defs ? b.defs.join(',') : 'G';
  if (ka === kb) continue;
  changed++;
  const name = a.ref.identifier.name, hoist = (b && b.ref.resolved ? b.ref.resolved.scope.block : a.ref.from.variableScope.block);
  const key = name + ' | in ' + label(hoist.type === 'Program' ? ast : (isFn(hoist) ? hoist : fnOf(hoist)));
  const g = groups.get(key) || []; g.push({ pos, write: a.ref.isWrite(), init: a.ref.init, before: D(a.defs), after: D(b && b.defs) }); groups.set(key, g);
}
console.log('\n== 1. references whose declaration set changed: ' + changed + ' in ' + groups.size + ' groups');
for (const [k, g] of groups) {
  console.log('\n-- ' + k + ' (' + g.length + ' refs)');
  const byChange = new Map(); g.forEach(r => { const c = r.before + '  ->  ' + r.after; (byChange.get(c) || byChange.set(c, []).get(c)).push(r); });
  for (const [c, rs] of byChange) console.log('   was [' + c.replace('  ->  ', ']  now [') + ']\n      at ' + rs.map(r => LC(r.pos) + (r.write ? (r.init ? '(init)' : '(WRITE)') : '')).join(' '));
}

// ---- 4. per converted let
const varsOf = l => { const out = []; for (const s of smA.scopes) for (const v of s.variables) if (v.defs.some(d => d.parent === l.node)) out.push(v); return out; };
const outerFnInside = (scope, hoistScope) => { let s = scope.variableScope; while (s.upper && s.upper.variableScope !== hoistScope) s = s.upper.variableScope; return s.block; };
const evalCalls = []; (function walk(n) { if (!n || typeof n.type !== 'string') return; if (n.type === 'CallExpression' && n.callee.type === 'Identifier' && n.callee.name === 'eval') evalCalls.push(n);
  for (const k of Object.keys(n)) { if (['type', 'start', 'end', 'loc', 'range'].includes(k)) continue; const v = n[k]; if (Array.isArray(v)) v.forEach(c => c && typeof c.type === 'string' && walk(c)); else if (v && typeof v.type === 'string') walk(v); } })(ast);
const flags = new Map(); const add = (l, f) => { const a = flags.get(l) || []; a.push(f); flags.set(l, a); };
const sections = { loopCap: [], noInit: [], tdz: [], early: [], sw: [], ev: [], wide: [], prog: [] };
for (const l of conv) {
  const vars = varsOf(l);
  for (const v of vars) {
    const hoistScope = v.scope.variableScope, dnode = v.defs.find(d => d.parent === l.node).node;
    const loopNodes = l.loops; // loops between the declaration and its function (incl. the one whose head it is)
    for (const r of v.references) {
      const p = r.identifier.start, sameFn = r.from.variableScope === hoistScope;
      if (!sameFn) {
        const f = outerFnInside(r.from, hoistScope);
        const inLoop = loopNodes.find(L => L.start <= f.start && f.end <= L.end);
        if (inLoop) { const cp = parent.get(f); sections.loopCap.push(v.name + ' (' + l.key + ', loop ' + LC(inLoop.start) + ') read in a function created inside the loop: ' + fnLabel(f) + '@' + LC(f.start) + ' ref ' + LC(p)); add(l, 'loop-capture'); }
        if (f.start < dnode.end) { sections.early.push(v.name + ' (' + l.key + ' in ' + label(l.fn) + ') read at ' + LC(p) + ' inside ' + fnLabel(f) + '@' + LC(f.start) + ' (created before the declarator)'); add(l, 'closure-before'); }
      } else if (p < dnode.end && !(r.init && p >= dnode.id.start && p < dnode.id.end)) {
        sections.tdz.push(v.name + ' (' + l.key + ' in ' + label(l.fn) + ') ' + (r.isWrite() ? 'written' : 'read') + ' at ' + LC(p) + ' before its declarator ends: …' + ctx(p, p + v.name.length, 50) + '…'); add(l, 'tdz');
      }
      if (l.inCase) { const own = l.inCase; if (!(p >= own.start && p < own.end)) { sections.sw.push(v.name + ' (' + l.key + ') used in another case at ' + LC(p)); add(l, 'switch-cross'); } }
    }
    // a direct eval inside the same function, in the region where the let is visible
    for (const E of evalCalls) {
      if (fnOf(E) !== l.fn) continue;                                   // only an eval in the let's own function sees the let/var difference
      const blk = v.scope.block;
      if (blk.start <= E.start && E.end <= blk.end) { sections.ev.push(v.name + ' (' + l.key + ' in ' + label(l.fn) + ') is visible to the direct eval at ' + LC(E.start) + (v.scope === hoistScope ? ' (function level)' : ' (block level, scope ' + v.scope.type + ')') + (E.start < dnode.end ? ' — the eval runs before this declarator ends' : '')); add(l, 'eval-visible'); }
    }
    if (v.scope !== hoistScope) { add(l, 'block'); if (hoistScope.block === iife) { sections.wide.push(v.name + ' (' + l.key + ') becomes an IIFE-wide name'); add(l, 'iife-wide'); } }
    if (hoistScope.type === 'global') { sections.prog.push(v.name + ' (' + l.key + ') at program level -> window property'); add(l, 'program'); }
  }
  if (l.loops.length) for (const dd of l.decls) if (!dd.init && !(l.isHead && l.headOf.type !== 'ForStatement')) { sections.noInit.push(dd.ids.map(i => i.name).join(',') + ' (' + l.key + ' in ' + label(l.fn) + ') has no initialiser and sits in loop ' + LC(l.loops[0].start)); add(l, 'no-init-in-loop'); }
  if (l.loops.length) add(l, l.isHead ? 'loop-head' : 'loop-body');
}
const sec = (t, a) => { console.log('\n== ' + t + ': ' + a.length); a.forEach(x => console.log('   ' + x)); };
sec('2. closures created inside the loop that holds a converted let (check: called after that pass?)', sections.loopCap);
sec('3. converted declarators without initialiser inside a loop (var keeps the previous pass value)', sections.noInit);
sec('4. references before the declarator ends, same function (let: error; var: undefined)', sections.tdz);
sec('5. switch: converted let used from another case', sections.sw);
sec('6. converted lets visible to a direct eval inside their own function', sections.ev);
sec('7. block lets of the IIFE that become IIFE-wide names', sections.wide);
sec('8. program-level lets (window properties)', sections.prog);
console.log('\n== 9. closures created before a converted declarator (deferred reads; they would throw under let if called before it): ' + sections.early.length);
if (listAll) sections.early.forEach(x => console.log('   ' + x));
else { const by = {}; sections.early.forEach(x => { const k = x.split(' (')[0]; by[k] = (by[k] || 0) + 1; }); console.log('   by name: ' + Object.entries(by).map(([k, n]) => k + ':' + n).join(' ')); }

console.log('\n== 10. every let declaration');
for (const l of lets) {
  const names = l.decls.map(d => d.ids.map(i => i.name).join(',') + (d.init ? '' : '(no init)')).join(' ');
  console.log('   ' + l.key.padEnd(10) + (keep.has(l.key) ? 'KEEP ' : 'var  ') + (l.direct ? 'fn-level ' : l.isHead ? 'loop-head' : 'block    ') + ' in ' + label(l.fn).padEnd(34) + ' ' + names + (flags.get(l) ? '  [' + [...new Set(flags.get(l))].join(', ') + ']' : ''));
}

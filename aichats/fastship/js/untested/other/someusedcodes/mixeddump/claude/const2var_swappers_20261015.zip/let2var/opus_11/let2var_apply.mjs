// let2var_apply.mjs <in.html> <out.html> [keep positions L<line>:<col> ...]
// Writes <out.html> = <in.html> with every `let` declaration of the <script> turned into `var` (same length, so every
// other byte stays), except the declarations whose `let` keyword sits at one of the given positions.
// Then checks the result: it parses; outside the converted keywords it is byte-identical to the input; the token
// streams differ only in those keywords; and lists every identifier reference whose variable changed (eslint-scope,
// optimistic mode so the app's direct evals do not hide anything), grouped by the variable it now belongs to.
import fs from 'fs';
import { createRequire } from 'module';
import * as acorn from '/opt/node22/lib/node_modules/eslint/node_modules/acorn/dist/acorn.mjs';
const require = createRequire(import.meta.url);
const eslintScope = require('/opt/node22/lib/node_modules/eslint/node_modules/eslint-scope');
const [inPath, outPath, ...keepArgs] = process.argv.slice(2);
const keep = new Set(keepArgs);
const html = fs.readFileSync(inPath, 'utf8');
const m = html.match(/<script>([\s\S]*?)<\/script>/);
const src = m[1], scriptStart = m.index + '<script>'.length;
const lineOff = html.slice(0, scriptStart).split('\n').length - 1;
const lineStarts = [0]; for (let i = 0; i < src.length; i++) if (src[i] === '\n') lineStarts.push(i + 1);
const lineOf = pos => { let lo = 0, hi = lineStarts.length - 1; while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (lineStarts[mid] <= pos) lo = mid; else hi = mid - 1; } return lo + 1 + lineOff; };
const at = pos => { const l = lineOf(pos); return 'L' + l + ':' + (pos - lineStarts[l - 1 - lineOff] + 1); };
const parse = s => acorn.parse(s, { ecmaVersion: 'latest', sourceType: 'script', ranges: true });
const ast = parse(src), lets = [];
(function walk(n) { if (!n || typeof n.type !== 'string') return; if (n.type === 'VariableDeclaration' && n.kind === 'let') lets.push(n);
  for (const k of Object.keys(n)) { const v = n[k]; if (Array.isArray(v)) v.forEach(walk); else if (v && typeof v.type === 'string') walk(v); } })(ast);
lets.sort((a, b) => a.start - b.start);
const seen = new Set();
let out = '', last = 0, conv = 0;
for (const l of lets) {
  if (src.slice(l.start, l.start + 3) !== 'let') throw new Error('no let keyword at ' + at(l.start));
  const p = at(l.start); if (keep.has(p)) { seen.add(p); continue; }
  out += src.slice(last, l.start) + 'var'; last = l.start + 3; conv++;
}
out += src.slice(last);
for (const k of keep) if (!seen.has(k)) throw new Error('keep position not found: ' + k);
const outHtml = html.slice(0, scriptStart) + out + html.slice(scriptStart + src.length);
fs.writeFileSync(outPath, outHtml);
console.log('let declarations: ' + lets.length + '; converted: ' + conv + '; kept: ' + keep.size + ' (' + [...keep].join(' ') + ')');
// 1. parse
const ast2 = parse(out); console.log('result parses: ok');
// 2. byte comparison: same length, and the only differing bytes are the converted keywords
if (outHtml.length !== html.length) throw new Error('length changed');
const diffs = []; for (let i = 0; i < html.length; i++) if (html[i] !== outHtml[i]) diffs.push(i);
const kwPos = new Set(lets.filter(l => !keep.has(at(l.start))).flatMap(l => [l.start, l.start + 1, l.start + 2].map(x => x + scriptStart)));
console.log('differing characters: ' + diffs.length + ' (expected ' + kwPos.size + '), all inside converted keywords: ' + diffs.every(d => kwPos.has(d)));
// 3. token streams
const toks = s => [...acorn.tokenizer(s, { ecmaVersion: 'latest' })].map(t => ({ v: t.type.label === 'name' || t.type.keyword ? (t.value ?? t.type.label) : t.type.label + ':' + (t.value ?? ''), s: t.start }));
const A = toks(src), B = toks(out); let td = 0, tbad = 0;
if (A.length !== B.length) throw new Error('token count differs ' + A.length + ' vs ' + B.length);
for (let i = 0; i < A.length; i++) if (A[i].v !== B[i].v) { td++; if (!(A[i].v === 'let' && B[i].v === 'var')) tbad++; }
console.log('tokens: ' + A.length + '; differing: ' + td + ' (all let -> var: ' + (tbad === 0) + ')');
// 4. binding comparison
const refsOf = (a) => { const sm = eslintScope.analyze(a, { ecmaVersion: 2022, sourceType: 'script', optimistic: true }), map = new Map();
  for (const sc of sm.scopes) for (const r of sc.references) map.set(r.identifier.start, r); return { sm, map }; };
const R1 = refsOf(ast), R2 = refsOf(ast2);
const letStarts = new Set(lets.map(l => l.start));
const kind = d => d.type === 'Variable' ? (letStarts.has(d.parent.start) ? (keep.has(at(d.parent.start)) ? 'let(kept)' : 'let->var') : d.parent.kind) : d.type;
const key = v => v ? v.defs.map(d => d.name.start).sort((x, y) => x - y).join(',') : 'global';
const desc = v => v ? v.defs.map(d => kind(d) + ' ' + d.name.name + '@' + at(d.name.start)).join(' + ') : 'global';
const groups = new Map(); let nChanged = 0;
for (const [pos, r] of R1.map) { const r2 = R2.map.get(pos); if (!r2) throw new Error('reference lost at ' + at(pos));
  if (key(r.resolved) === key(r2.resolved)) continue; nChanged++;
  const g = groups.get(desc(r2.resolved)) || { from: new Map(), refs: [] }; g.from.set(desc(r.resolved), (g.from.get(desc(r.resolved)) || 0) + 1);
  g.refs.push(at(pos) + (r.isWrite() ? 'w' : '') + (r.isRead() ? 'r' : '')); groups.set(desc(r2.resolved), g); }
console.log('references whose variable changes: ' + nChanged + ' in ' + groups.size + ' variables');
for (const [to, g] of groups) { console.log('  now: ' + to); for (const [f, n] of g.from) console.log('     ' + n + ' ref(s) were: ' + f); }
// 5. census of the result
const census = { let: 0, var: 0, const: 0 }; (function walk(n) { if (!n || typeof n.type !== 'string') return; if (n.type === 'VariableDeclaration') census[n.kind]++;
  for (const k of Object.keys(n)) { const v = n[k]; if (Array.isArray(v)) v.forEach(walk); else if (v && typeof v.type === 'string') walk(v); } })(ast2);
console.log('declarations in the result: ' + JSON.stringify(census));

# The lets that stayed `let` (candidate 5 files)

Written by the helper on 2026-10-15 after the four-way let → var run. The user's question: «also give me section that kept lets so i can check myself».

All four builders (0f, 10, 11, 12) started from candidate 4 (`const2var/ai_chatvar_candidate4.html`, sha256 689307a0: 0 const, 160 let, 402 var). The lines below are copied byte-exact from the candidate files. Two files exist:

- **keep-4** = `let2var/opus_10/ai_chatvar_candidate5_10.html` = `opus_11/…_11.html` = `opus_12/…_12.html` (byte-identical, sha256 ac6c141a, 150,329 B): 4 let, 558 var.
- **keep-8** = `const2var/ai_chatvar_candidate5.html` (copy 0f, sha256 36d046aa, 150,329 B): 8 let, 554 var.

They differ on exactly one line, L521. Lines 675 and 676 are identical in both.

## L675, `normalizeUsage` (1 let kept, both files)

The function starts `function normalizeUsage(t,e={}){var n={...t},u=n._||{};delete n._;var i=…,o=i,l=0,…`. That function-level `l` is the "unpriced" flag: at the end `l&&(n.unpriced=!0)`. Inside the block `if(null!=n.input){…}` a temporary with the same name is declared: `let l=cacheSum(n)`. It is the one `let` on the line.

- As `var` it would be the same variable as the flag, so every reply whose usage has cache counts would be stored as unpriced and its cost shown with a `+` (copy 10: 5,114 of 20,000 fuzz rounds differ; copy 11: 6,098 of 20,000; copy 12: 27,515 of 50,000).
- In candidate 4 this spot was a parse error as `var` (the outer `l` was still `let`). Once the outer `l` became `var`, it parses, and the clash becomes a silent one.

Full line (keep-4 and keep-8 are the same here):

```
function normalizeUsage(t,e={}){var n={...t},u=n._||{};delete n._;var i=!!Object.keys(u).length,o=i,l=0,s=e.reasoningInOutput,d=e.cacheRemainder;void 0!==s&&!0!==s&&!1!==s&&(s=void 0,i=o=l=1);for(var t of tokenKeys)null!=n[t]&&(!Number.isSafeInteger(n[t])||n[t]<0)&&(n[t]=void 0,u[t]=1,i=o=1);null!=n.fee&&null==nn(n.fee)&&(n.fee=void 0,i=o=1);var a=null!=n.output,c=n.reasoning??0;if(!a&&!u.output&&null!=n.input&&null!=n.total&&n.total>=n.input&&(n.output=n.total-n.input),a&&c){var t=safeSum(n.input,n.output),e=safeSum(n.input,n.output,c);if(!1===s||null==s&&null!=n.input&&n.total===e){var t=safeSum(n.output,c);null==t?(n.output=void 0,i=o=l=1):n.output=t}else!0===s&&c>n.output?i=o=l=1:null!=s||null!=n.input&&n.total===t||(i=l=1)}if(c&&null!=n.output&&c>n.output&&(i=o=l=1),null!=n.input||u.input||null==n.output||null==n.total||!(n.total>=n.output)||c&&null==s&&a||(n.input=n.total-n.output),null!=n.input){var t=cacheKeys.filter(t=>null==n[t]),e=cacheSum(n);null==e?i=o=1:1!==t.length||u[t[0]]||d!==t[0]||(e<=n.input?n[t[0]]=n.input-e:i=o=1);let l=cacheSum(n);(null==l||l>n.input)&&(cacheKeys.forEach(t=>n[t]=void 0),i=o=1)}var r=cacheSum(n),p=null==r?void 0:Math.max(n.input??0,r),f=null==p?void 0:safeSum(n.output,p);null==f?(n.total=void 0,i=o=1):(null!=n.total&&n.total<f&&(i=o=1),n.total=Math.max(n.total??0,f));var h=null!=n.input&&null!=r?Math.max(0,n.input-r):0,m=null!=n.total&&null!=p?Math.max(0,n.total-(n.output??0)-p):0,_=safeSum(n.cacheWrite,h,m);return n.unknown=_??0,null==_&&(i=o=1),(null==n.input||null==n.output||h||m)&&(i=1),i&&(n.partial=!0),o&&(n.conflict=!0),l&&(n.unpriced=!0),n}
```

## L676, `priceUsage` (3 lets kept, both files)

Signature `function priceUsage(t,e={},n)`: `t` = the usage object, `e` = the price table, `n` = the provider-reported cost (may be undefined). The three kept lets are block temporaries that reuse a parameter's or an outer variable's name:

1. `if(a){let n=nn(e.inputUnknown);…}` shadows the parameter `n`. As `var` the reported cost is overwritten before `var p=nn(n)` reads it, so the stored exact cost becomes a one-token price or disappears (copy 10: 3,199 of 20,000 differ; copy 11: 5,445; copy 12: 8,387 of 50,000). This one was an app `let` already.
2. `else{let t=p-r;…}` inside `if(null!=p){… return{usage:t,…}}` shadows the parameter `t`. As `var` the function returns a number instead of the usage and the message loses its token counts (the miss the three const-pass checkers found; copy 10: 11,848 of 20,000 differ).
3. `for(let e in l)` inside that else branch shadows the block variable `e` (the split flag, `var e=p+moneyEpsilon(p,r)<r`). As `var` the flag ends as a key name, so `split` is returned true in the branch where a reported cost is a hair below the computed one (copy 10: 156 of 20,000 differ; copy 11: 8,252; copy 12: 4 of 50,000).

Full line:

```
function priceUsage(t,e={},n){e={...asArr(e.tiers).reduce((a,x)=>nn(x?.minInput)<=t.input&&(!a||+x.minInput>+a.minInput)?x:a,0),...e};var u={},i={out:e.output,hit:e.inputCacheHit??e.input,miss:e.inputCacheMiss??e.input,write:e.inputCacheWrite},o=(t,e,n)=>{if(!t)return 0;var i=nn(e),o=t*(i??0);return null!=i&&Number.isFinite(o)||(u[n]=1),null!=i&&Number.isFinite(o)?o:0};var l={out:o(t.output,i.out,"out"),hit:o(t.cacheHit,i.hit,"hit"),miss:o(t.cacheMiss,i.miss,"miss"),unk:o(t.cacheWrite,i.write,"unk")};var s=cacheSum(t),a=null!=t.input&&null!=s?Math.max(0,t.input-s):0,c=Math.max(0,(t.unknown??0)-(t.cacheWrite??0)-a);if(a){let n=nn(e.inputUnknown);if(null==n){var e=[["cacheHit",i.hit],["cacheMiss",i.miss],["cacheWrite",i.write]].filter(([e])=>0!==t[e]).map(([,t])=>nn(t));e.length&&e.every(t=>null!=t&&t===e[0])&&(n=e[0])}l.unk+=o(a,n,"unk")}(c||t.fee||null==t.input||null==t.output||t.unpriced||t.conflict)&&(u.unk=1);var r=Object.values(l).reduce((t,e)=>t+e,0);Number.isFinite(r)||(l={out:0,hit:0,miss:0,unk:0},r=0,u.unk=1);var p=nn(n);if(null!=p){var e=p+moneyEpsilon(p,r)<r;if(e)l={out:0,hit:0,miss:0,unk:p};else{let t=p-r;if(t>=0)l.unk+=t;else{var n=0;for(let e in l)if(l[e]>=-t){l[e]+=t,n=1;break}n||(l={out:0,hit:0,miss:0,unk:p},e=1)}}return{usage:t,cost:l,total:p,unresolved:!1,split:e||!!Object.keys(u).length||!!t.partial||!!t.conflict,missing:u}}return{usage:t,cost:l,total:r,unresolved:!!Object.keys(u).length,missing:u}}
```

## L521, the swarm agent selector `AA` (the one line that differs)

`AA()` evaluates each agent's `priority` and `frequency` text with a direct `eval`, inside a try/catch whose catch shows the toast `⚠️ Agent [id] Error: …`. The eval'd text sees AA's own locals `h` (best agent so far), `p` (its priority), `d` (depth = visible nodes + 1), `i` (agent id), `a` (agent object) and `P` (this agent's priority), plus everything else in the app's closure.

keep-8 (copy 0f) leaves those six as `let`:

```
var agents={interrupt:{id:'interrupt',on:1,interrupt:'user',priority:0},...JL('dse_agents')},G=agents._??={id:'_',on:1,priority:1,$:'frequency:t/priority:t/edit:e/on:b'},IH={user:()=>0},INT=a=>(IH[a?.interrupt]||IH.user)(a);for(var i in agents)agents[i].$??=G.$;var AA=()=>{let h,p=-1/0,d=getViewNodes().length+1;for(let i in agents){let a=agents[i];try{let P=+eval(a.priority??1);i!='_'&&a.on&&(!a.frequency||eval(a.frequency))&&P>p&&(h=i,p=P)}catch(e){showToast(`⚠️ Agent [${i}] Error: ${e.message}`)}}return h?(!agents[h].interrupt||INT(agents[h]))&&h:INT()};
```

keep-4 (copies 10, 11, 12) makes them `var`:

```
var agents={interrupt:{id:'interrupt',on:1,interrupt:'user',priority:0},...JL('dse_agents')},G=agents._??={id:'_',on:1,priority:1,$:'frequency:t/priority:t/edit:e/on:b'},IH={user:()=>0},INT=a=>(IH[a?.interrupt]||IH.user)(a);for(var i in agents)agents[i].$??=G.$;var AA=()=>{var h,p=-1/0,d=getViewNodes().length+1;for(var i in agents){var a=agents[i];try{var P=+eval(a.priority??1);i!='_'&&a.on&&(!a.frequency||eval(a.frequency))&&P>p&&(h=i,p=P)}catch(e){showToast(`⚠️ Agent [${i}] Error: ${e.message}`)}}return h?(!agents[h].interrupt||INT(agents[h]))&&h:INT()};
```

The top-level loop `for(var i in agents)agents[i].$??=G.$;` is `var` in both files, so after start-up `i` (the last agent key, usually `_`) is a visible name in the app's closure in both; before, reading a bare `i` there was a ReferenceError.

What differs between keep-8 and keep-4, only inside agent expressions:

| agent priority / frequency text | keep-8 (let) | keep-4 (var) |
|---|---|---|
| ordinary expression (`1`, `d%2==0`, `Math.random()<.3`, reads of settings/chatTree) | same | same |
| assigns one of the six (`p=0`) | same (allowed) | same |
| declares one of the six with `var` or `function` (`var i="A";9`, `var p=100;true`) | SyntaxError → toast, agent skipped | no error; the declaration overwrites AA's variable for the rest of the loop (e.g. `var p=100` in a frequency → no agent answers) |
| reads `P` inside its own priority | ReferenceError (TDZ) → toast, agent skipped | the previous agent's `P` (undefined for the first) |
| any other error (typo, unknown name, bad syntax) | toast | toast |

`let` and `const` written inside an agent expression stay inside the eval in both files, so they never clash.

## Zero-let variants (optional)

- `opus_10/ai_chatvar_candidate5_10_nolet.html` (sha256 53a4c899, 150,329 B): keep-4 with the four temporaries renamed `l`→`g` (L675), `n`→`g`, `t`→`d`, `e`→`k` (L676), then `var`. 0 let, 562 var. Passed copy 10's fuzz (20,000 rounds, 0 differences) and headless run.
- `opus_12/ai_chatvar_candidate5_12_zero_let.html` (sha256 d08fa683, +15 B): keep-4 with the four renamed `l2`/`n2`/`t2`/`e2`. Passed copy 12's tests.

Both edit the minified text beyond a keyword swap, so the diff against the original app is no longer keyword-only on those two lines. No hook can reach those four temporaries, so the gain is only "no `let` anywhere".

<!-- report written by core Opus copy 0f (its final reply, saved verbatim by the helper because the harness blocks report files from subagents) -->

I couldn't write `let2var/REPORT.md`: the harness blocks report files from me. The report text is below, so you can save it there.

# let → var in ai_chat.html: candidate 5

The user's message (2026-10-15 07:16Z): «hmm if can be done without any issue i guess better to do it while at it, so i can optimize hooks etc a lot better later on». I did the pass on a copy of candidate 4, which has no `const` and 160 `let`s. The repo is untouched.

## Result
- **`const2var/ai_chatvar_candidate5.html`** (sha256 36d046aa…, 150,329 bytes): **152 of the 160 `let`s are now `var`.** It has 0 `const`, 554 `var` and 8 `let`, all 8 inside three functions. The 120 `function` declarations are unchanged.
- **Every name at the app's top level is now `var` or `function`.** The 8 `let`s left are locals of `AA`, `normalizeUsage` and `priceUsage`, which nothing outside those functions can reach.
- **Only the keyword changed.** Against candidate 4, 152 `let` became `var`; the keyword has the same length, so every line and position is unchanged. Comments, strings and the HTML are identical.
- **No difference from the original or candidate 4 in any test:**
  - pricing code: 1.1 million cases;
  - the chat-repair code: 30,000 damaged chats;
  - headless browser: 6 scenarios;
  - the four 99 add-ons: 12 runs.

## The 8 that stay `let`

| Where | Declaration | What `var` breaks |
|---|---|---|
| `normalizeUsage` (L675) | block `let l=cacheSum(n)` | the "cannot be fully priced" flag |
| `priceUsage` (L676) | `let n=nn(e.inputUnknown)` | the cost the provider reported |
| `priceUsage` (L676) | `let t=p-r` | the stored token usage (the const-pass bug) |
| `priceUsage` (L676) | `for (let e in l)` | the `split` flag |
| `AA`, agent selection (L521) | `let h,p,d`, `for (let i in agents)`, `let a`, `let P` | agent `priority`/`frequency` expressions |

**The four pricing ones.** In each case the block reuses the name of a parameter or of the function's own variable, which is read later. As `var` the two merge, and the block's temporary value overwrites it. To prove it, I made candidate 5 with only that one keyword switched to `var` and ran it against the original:
- **`normalizeUsage` `l`:** the flag takes a token sum, so replies wrongly gain or lose the "+" (part of the cost unknown). 20,555 of 200,000 random cases differ.
- **`priceUsage` `n`:** the reported cost is lost whenever some input tokens are not split into hit, miss or write. 17,662 of 200,000 differ.
- **`priceUsage` `t`:** the usage is saved as a number. 50,959 of 200,000 differ.
- **`priceUsage` loop `e`:** `split` becomes `"miss"` instead of true or false. Random inputs never reach this branch, so I wrote a targeted test: 227,692 of 600,000 cases differ.

**`AA`.** It runs each agent's `priority` and `frequency` text through `eval` inside its loop, so `h`, `p`, `d`, `i`, `a` and `P` are visible to that text.
- With `let`, an expression like `var p = 5; p` shows an error toast ("Identifier 'p' has already been declared"), and the other agents still compete.
- With `var` it silently overwrites the selection state. In the test, no agent was picked and no error was shown (`eval_demo.txt`).

These names are locals of `AA`, so turning them into `var` gives hooks nothing. Doing it anyway is 4 keywords on L521; I don't recommend it.

## Why the other 152 are harmless
1. **Blocks with the same name now share one variable:** 109 references in 30 groups (eslint-scope, with resolution that sees through the app's direct `eval`). Each group is safe:
   - **`regChange` (L557):** each of its three `if` blocks sets its names first and ends with `return`, so nothing passes between blocks.
   - **`usageValue` (L671):** the array branch always returns, so its names never meet the text branch's.
   - **`priceUsage`:** the rounding flag `e` and the inner `n=0` merge with the parameters `e` and `n`, but both parameters are only read before those blocks.
   - **`for (let i …)` loops:** `renderPathTopoAware` (L943–L946) and the message click handler (L1337–L1338) now share one `i`. Each loop sets `i` first.
   - **`saveHistory` `k` and `healTree` `arr`:** each block sets the name before reading it.
2. **Loops.** A `var` is one copy for all passes. Only 4 functions created inside a loop read such a name: three `forEach` callbacks in `saveHistory` and the Promise executor in `bootRead`. All run immediately, inside the same pass. No `let` in a loop body was missing a starting value.
3. **Reads before the declaration.** With `let` these throw; with `var` they give `undefined`.
   - **Same function:** none.
   - **Start-up:** 238 references go from function declarations to the 49 top-level `let`s. The first top-level `await` (L1373) comes after the last of them (L1347), and no earlier statement calls code that reads one.
   - **Runtime:** no ReferenceError, with every exception recorded (caught ones included).
4. **Nothing else:** no switch-case crossings, `catch`-name clashes, functions inside blocks, or uses of `arguments`.

## How it was checked
- **Conversion and binding comparison:** `tools/let2var_apply.mjs`, which also tests each `let` alone. Two of them fail to parse on their own.
- **Scans:** `let2var_hazards.mjs` and `boot_tdz.mjs`.
- **Text check:** `tokdiff2.mjs`. Compared with the original, the full change is 402 `const`→`var`, 3 `const`→`let` and 152 `let`→`var`.
- **Pricing:** the three const-pass harnesses (opus_e/d/c; 200,000 / 120,000 / 200,000 cases) and `near_eps.mjs` (600,000 cases where the reported cost is equal, just above or just below the computed one). All gave 0 differences.
- **`healTree`:** 30,000 random damaged trees with a frozen clock, 0 differences. The two `arr` blocks ran 33,009 and 23,244 times.
- **Headless Chromium** (`e2e_ab.mjs`: opus_d's harness plus three scenarios and exception capture), with a mock provider and fresh storage per page. The original, candidate 4 and candidate 5 each ran through:
  - **One tab:** send, regenerate, versions, inline branch, branch switch, thinking toggle, an xAI reported cost, cost popups, a non-streamed reply, "Update text only", and reload mid-reply.
  - **Two tabs** writing in turn (the merge path).
  - **Recovery** of a cut reply from the stream buffer.
  - **Every `regChange` branch:** a field, on/off, "Edit keys", key rename, "Set all", provider ＋, Apply JSON, provider switch, Save and reload.
  - **Unread-version dots**, jumping left and right.
  - **Import:** branch mode, a damaged chat through the repair dialog, replace, restore from backup, and a renamed import.

  Result: 0 differing values in all scenarios.
- **The four add-ons** (99.js 5.1.0, B1 5.1.4, B2 5.1.5, B3 5.1.6). The only difference from the original is `CHAT_ID` being reassignable, the intended const-pass change, same as on candidate 4. Everything else is identical: 12–13 swaps, `disable()` restores everything, the same 5 requests, the export, the chat tree and the screen. No errors.

## What `var` gives for hooks
- **In the app's own source:** a later `var x = …` or `function x(){}` in the same scope is now legal at the top level. Before, redeclaring a `let` name stopped the whole page from loading.
- **Assigning (`x = …`)** from the console, add-ons or tools already worked on `let` and still works.
- **A `var x = …` typed in the eval console never reaches the app's `x`, before or after this change.** It makes a local copy (`eval_demo.txt`). So console hooks should assign, not redeclare.

## Side effects that remain
- **One new top-level name, `i`.** It comes from the start-up loop over agents (L521) and holds the last agent id. Nothing in the app or the four add-ons reads a free `i`.
- **Early reads:** a read before a declaration would now give `undefined` instead of an error. No such read exists.

## Noticed, not changed
The Swarm tab's agent ＋ throws "r.active is not a function" in the original too. `regClick` calls `r.active()` before checking that the click is an add, and the agent registry has no `active()`. The provider ＋ works.

## Files
Everything is in `const2var/`:
- **Result:** `ai_chatvar_candidate5.html`. `let2var/draft_keep8.html` is the same bytes.
- **Not usable:** `let2var/draft_all.html` (all 160 as `var`).
- **Test copies:** `let2var/mutants/` (the four one-keyword mutants) and `let2var/cov_orig_heal.html` (coverage copy for the `healTree` counts).
- **Scripts:** `let2var/tools/`.
- **Outputs, in `let2var/`:** `apply_keep8.txt`, `hazards_keep8.txt`, `boot_tdz.txt`, `tokdiff.txt`, `census.txt`, `pricing_fuzz.txt`, `mutants_fuzz.txt`, `near_eps.txt`, `heal_fuzz.txt`, `eval_demo.txt`, `e2e_run1.jsonl`, `e2e_run1_cmp.txt`, `addon_run1.jsonl`, `addon_cmp.txt`.

The `sk-test-…` and `xai-test-…` strings in the scripts and outputs are fake keys for the mock provider, not real API keys.
// nolet_variant.mjs <cand5.html> <out.html> : the optional "no let at all" variant. Each of the four lets candidate 5 keeps
// is renamed to a one-letter name its function does not use (so no position moves), then made `var`:
//   normalizeUsage  block `let l=cacheSum(n)`        -> `var g`
//   priceUsage      block `let n=nn(e.inputUnknown)` -> `var g`
//   priceUsage      block `let t=p-r`                -> `var d`
//   priceUsage      loop  `for(let e in l)`          -> `for(var k in l)`
// Every reference of each renamed binding is found with eslint-scope (not by text), and the new name is checked to be
// unused in the whole function first.
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'url';
import { resolve as __rp } from 'path';
const __NM = process.env.NODE_MODULES || 'node_modules';   // folder that holds acorn and eslint-scope (npm install acorn eslint-scope)
const acorn = await import(pathToFileURL(__rp(__NM, 'acorn/dist/acorn.mjs')).href);
const require = createRequire(import.meta.url);
const eslintScope = require(__rp(__NM, 'eslint-scope'));
const [inPath, outPath] = process.argv.slice(2);
const html = fs.readFileSync(inPath, 'utf8'), m = html.match(/<script>([\s\S]*?)<\/script>/), start = m.index + 8;
let src = m[1];
const ast = acorn.parse(src, { ecmaVersion: 'latest', sourceType: 'script', ranges: true });
const sm = eslintScope.analyze(ast, { ecmaVersion: 2022, sourceType: 'script', optimistic: true });
const lets = []; (function walk(n) { if (!n || typeof n.type !== 'string') return; if (n.type === 'VariableDeclaration' && n.kind === 'let') lets.push(n);
  for (const k of Object.keys(n)) { if (['type', 'start', 'end', 'loc', 'range'].includes(k)) continue; const v = n[k]; if (Array.isArray(v)) v.forEach(c => c && typeof c.type === 'string' && walk(c)); else if (v && typeof v.type === 'string') walk(v); } })(ast);
if (lets.length !== 4) throw new Error('expected 4 lets, found ' + lets.length);
const plan = [['l', 'g'], ['n', 'g'], ['t', 'd'], ['e', 'k']];
const edits = [];
lets.sort((a, b) => a.start - b.start).forEach((decl, i) => {
  const v = sm.scopes.flatMap(s => s.variables).find(x => x.defs.some(d => d.parent === decl));
  const [from, to] = plan[i]; if (v.name !== from) throw new Error('unexpected name ' + v.name);
  const fnScope = v.scope.variableScope, fn = fnScope.block;
  // the new name must not occur as any identifier inside the function
  const used = new Set(); (function walk(n) { if (!n || typeof n.type !== 'string') return; if (n.type === 'Identifier') used.add(n.name);
    for (const k of Object.keys(n)) { if (['type', 'start', 'end', 'loc', 'range'].includes(k)) continue; const x = n[k]; if (Array.isArray(x)) x.forEach(c => c && typeof c.type === 'string' && walk(c)); else if (x && typeof x.type === 'string') walk(x); } })(fn);
  if (used.has(to)) throw new Error('name ' + to + ' already used in ' + (fn.id ? fn.id.name : 'function'));
  edits.push({ pos: decl.start, len: 3, text: 'var' });
  for (const d of v.defs) edits.push({ pos: d.name.start, len: 1, text: to });
  for (const r of v.references) if (r.identifier !== v.defs[0].name) edits.push({ pos: r.identifier.start, len: 1, text: to });
  console.log((fn.id ? fn.id.name : 'fn') + ': let ' + from + ' -> var ' + to + ' (' + v.references.length + ' references)');
});
const uniq = [...new Map(edits.map(e => [e.pos, e])).values()].sort((a, b) => b.pos - a.pos);
for (const e of uniq) { if (e.len === 1 && !/^[a-z]$/.test(src[e.pos])) throw new Error('bad pos ' + e.pos); src = src.slice(0, e.pos) + e.text + src.slice(e.pos + e.len); }
acorn.parse(src, { ecmaVersion: 'latest', sourceType: 'script' });
fs.writeFileSync(outPath, html.slice(0, start) + src + html.slice(start + m[1].length));
console.log('edits: ' + uniq.length + '; written ' + outPath);

// zero_let.mjs <cand5.html> <out.html> (copy opus_12)
// The optional zero-let variant: the four declarations that cannot become `var` by keyword alone get fresh local names
// (l2, n2, t2, e2; none of them occurs anywhere in the file), then `var`. Every replaced snippet must occur exactly once.
import fs from 'fs';
import vm from 'vm';
import { loadPage, parse, walk } from './lib.mjs';
const [inPath, outPath] = process.argv.slice(2);
const P = loadPage(inPath);
let s = P.src;
const edits = [
  // normalizeUsage: the block temporary `l` (the function's own `l` is the "unpriced" flag read at the end)
  ['let l=cacheSum(n);(null==l||l>n.input)&&(', 'var l2=cacheSum(n);(null==l2||l2>n.input)&&('],
  // priceUsage: the rate `n` of the unknown input (the parameter `n` is the reported cost, read later by nn(n))
  ['if(a){let n=nn(e.inputUnknown);if(null==n){', 'if(a){var n2=nn(e.inputUnknown);if(null==n2){'],
  ['&&(n=e[0])}l.unk+=o(a,n,"unk")}', '&&(n2=e[0])}l.unk+=o(a,n2,"unk")}'],
  // priceUsage: the difference `t` (the parameter `t` is the usage returned as usage:t) and the loop key `e`
  // (the outer `e` is the split flag; the `e=1` after the loop stays the flag)
  ['else{let t=p-r;if(t>=0)l.unk+=t;else{var n=0;for(let e in l)if(l[e]>=-t){l[e]+=t,n=1;break}n||(',
   'else{var t2=p-r;if(t2>=0)l.unk+=t2;else{var n=0;for(var e2 in l)if(l[e2]>=-t2){l[e2]+=t2,n=1;break}n||(']
];
for (const [a, b] of edits) {
  const k = s.split(a).length - 1;
  if (k !== 1) throw new Error('expected one occurrence, found ' + k + ': ' + a);
  s = s.replace(a, b);
}
let lets = 0; walk(parse(s), n => { if (n.type === 'VariableDeclaration' && n.kind === 'let') lets++; });
new vm.Script(s);
console.log('zero-let variant: parses (acorn + V8), let declarations left: ' + lets);
fs.writeFileSync(outPath, P.withScript(s));
